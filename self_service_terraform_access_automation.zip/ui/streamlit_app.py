import sys
from pathlib import Path
import streamlit as st
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from app.config import settings,catalog
from app.models import AccessRequest
from app.workflow import Workflow
from app.diff import make_diff
st.set_page_config(page_title='Self-Service Terraform Access Automation',page_icon='🔐',layout='wide')
st.markdown('''<style>.stApp{background:#0b1020;color:#e8edf7}.block-container{max-width:1250px;padding-top:2rem}.hero{padding:1.5rem;border:1px solid #26314a;border-radius:18px;background:#111a31;margin-bottom:1.2rem}.kicker{color:#7dd3fc;font-weight:700;letter-spacing:.12em;text-transform:uppercase;font-size:.75rem}.hero h1{margin:.3rem 0}.small{color:#9aa8bd}.card{padding:1rem;border:1px solid #26314a;border-radius:14px;background:#111827}</style>''',unsafe_allow_html=True)
@st.cache_resource
def workflow():return Workflow()
def main():
    st.markdown('<div class="hero"><div class="kicker">Infrastructure Engineering Workspace</div><h1>Self-Service Terraform Access Automation</h1><p>Turn repetitive access tickets into validated Terraform changes and governed GitHub Pull Requests.</p></div>',unsafe_allow_html=True)
    cfg=settings(); cat=catalog(); wf=workflow()
    with st.sidebar:
        st.subheader('Deployment Target'); st.caption(f"{cfg['github_owner'] or 'owner'}/{cfg['target_repo'] or 'repository'}")
        branch=st.text_input('Base branch',cfg['target_branch']); ticket=st.text_input('Service ticket / request ID','REQ-12345')
        st.caption('The base branch is never modified directly.')
    st.subheader('1. Define the access request')
    op=st.selectbox('Access operation',list(cat),format_func=lambda x:cat[x]['label'])
    c=cat[op]; st.caption(c['description'])
    resource=scope=pid=role=''; ptype='Managed Identity'; access='Read'
    if op=='COSMOS_DB_ACCESS':
        a,b=st.columns(2); resource=a.text_input('Cosmos DB account','prod-cosmos'); access=b.radio('Access level',['Read','Read/Write'],horizontal=True); pid=st.text_input('Managed Identity Object ID',placeholder='xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx')
    else:
        a,b=st.columns(2); resource=a.text_input('Resource name','prod-storage'); scope=a.text_input('Resource scope','/subscriptions/...'); ptype=b.selectbox('Principal type',['Managed Identity','Group','Service Principal','User']); pid=b.text_input('Principal Object ID',placeholder='xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx'); role=st.selectbox('Approved role',c['allowed_roles']); access=role
    a,b=st.columns(2)
    if a.button('Analyze Repository',use_container_width=True):
        try:
            with st.spinner('Scanning branch recursively...'): st.session_state.scan=wf.scan_engine.scan(branch)
            st.success(f"Found {st.session_state.scan['terraform_file_count']} Terraform files.")
        except Exception as e:st.error(str(e))
    req=AccessRequest(op,cfg['target_repo'],branch,resource,scope,pid,ptype,access,role,ticket)
    if b.button('Validate & Preview',type='primary',use_container_width=True):
        v=wf.validate(req)
        if not v.valid:
            for e in v.errors:st.error(e)
        else:
            for w in v.warnings:st.warning(w)
            try: st.session_state.preview=wf.preview(req); st.success('Request validated and change calculated.')
            except Exception as e:st.error(str(e))
    if st.session_state.get('scan'):
        s=st.session_state.scan; st.subheader('2. Repository inventory'); a,b,c3=st.columns(3); a.metric('Terraform files',s['terraform_file_count']); b.metric('Directories',len(s['terraform_directories'])); c3.metric('Discovered paths',len(s['terraform_files']))
        with st.expander('Show Terraform paths'):
            for x in s['terraform_files']:st.code(x['path'])
    p=st.session_state.get('preview')
    if p:
        st.subheader('3. Proposed Terraform change'); st.markdown(f'<div class="card"><b>File:</b> {p.file_path}<br/><b>Summary:</b> {p.summary}</div>',unsafe_allow_html=True); st.code(make_diff(p.before,p.after,p.file_path) or 'No changes.',language='diff')
        if p.changed:
            st.subheader('4. Create Pull Request'); wb=st.text_input('Working branch',f'feature/access-{ticket.lower() or "request"}')
            if st.button('Create Branch + Pull Request',type='primary',use_container_width=True):
                req.working_branch=wb
                try:
                    with st.spinner('Creating branch and Pull Request...'):result=wf.publish(req,p)
                    st.success('Pull Request created.'); st.link_button('Open Pull Request',result['url']); st.code(result['branch'])
                except Exception as e:st.error(str(e))
    st.divider(); st.subheader('Automation flow'); cols=st.columns(6)
    for col,(n,t,d) in zip(cols,[('1','Request','Ticket inputs'),('2','Validate','Approved rules'),('3','Scan','Recursive repo analysis'),('4','Transform','Terraform change'),('5','Review','Exact diff'),('6','PR','Branch + PR')]):
        col.markdown(f'<div class="card"><b>{n}. {t}</b><div class="small">{d}</div></div>',unsafe_allow_html=True)
if __name__=='__main__':main()
