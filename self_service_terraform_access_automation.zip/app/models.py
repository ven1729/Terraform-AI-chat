from dataclasses import dataclass, field
from typing import List
@dataclass
class AccessRequest:
    operation:str; repository:str; base_branch:str; resource_name:str=''; resource_scope:str=''; principal_id:str=''; principal_type:str='Managed Identity'; access_level:str='Read'; role:str=''; ticket_id:str=''; working_branch:str=''
@dataclass
class ValidationResult:
    valid:bool; errors:List[str]=field(default_factory=list); warnings:List[str]=field(default_factory=list)
@dataclass
class ChangePreview:
    file_path:str; before:str; after:str; operation:str; summary:str; changed:bool=True
