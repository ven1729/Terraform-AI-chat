from datetime import datetime,timezone
import re
from app.config import settings,catalog
from app.models import AccessRequest,ValidationResult,ChangePreview
from app.github_client import GitHubClient
from app.scanner import RepositoryScanner
from app.transformers import TfvarsTransformer,RbacTransformer
class Workflow:
    def __init__(self):
        self.cfg=settings(); self.cat=catalog(); self.gh=GitHubClient(self.cfg['github_token'],self.cfg['github_owner'],self.cfg['target_repo'],self.cfg['github_api_url']); self.scan_engine=RepositoryScanner(self.gh); self.tf=TfvarsTransformer(); self.rb=RbacTransformer()
    def validate(self,r):
        e=[];w=[]
        if not r.base_branch:e.append('Base branch is required.')
        if not r.repository:e.append('Repository is required.')
        if not re.fullmatch(r'[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}',r.principal_id):e.append('Principal/Object ID must be a valid GUID.')
        c=self.cat[r.operation]
        if r.operation=='COSMOS_DB_ACCESS':
            if not r.resource_name:e.append('Cosmos DB account is required.')
            if r.access_level not in ('Read','Read/Write'):e.append('Invalid access level.')
        elif r.operation=='GENERIC_AZURE_RBAC':
            if not r.resource_scope:e.append('Resource scope is required.')
            if r.role not in c.get('allowed_roles',[]):e.append('Role is not approved.')
        else:e.append('Unsupported operation.')
        if not r.ticket_id:w.append('Ticket ID is recommended for traceability.')
        return ValidationResult(not e,e,w)
    def preview(self,r):
        c=self.cat[r.operation]; f=self.scan_engine.find(r.base_branch,c['file_pattern'])
        if c['kind']=='tfvars_list_append':
            var=c['read_variable'] if r.access_level=='Read' else c['read_write_variable']; after,changed=self.tf.append(f.content,var,r.principal_id)
        else: after,changed=self.rb.append(f.content,r.role,r.resource_scope,r.principal_id,r.principal_type,r.resource_name)
        return ChangePreview(f.path,f.content,after,r.operation,'Requested access change',changed)
    def publish(self,r,p):
        if not p.changed:raise RuntimeError('No change required; requested access already exists.')
        branch=r.working_branch or f"feature/access-{(r.ticket_id or 'request').lower()}-{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}"
        if branch==r.base_branch:raise ValueError('Working branch must differ from base branch.')
        self.gh.create_branch(r.base_branch,branch)
        self.gh.update_file(p.file_path,p.after,branch,f'chore(access): {r.operation.lower()}')
        body=f'''## Terraform Access Change\n\n- Ticket: `{r.ticket_id or 'N/A'}`\n- Operation: `{r.operation}`\n- Resource: `{r.resource_name or r.resource_scope}`\n- Principal: `{r.principal_id}`\n- Principal type: `{r.principal_type}`\n- Access: `{r.access_level}`\n- Changed file: `{p.file_path}`\n\nAutomated validation passed. Base branch was not modified directly. Please review the Terraform diff and approve according to repository governance.\n'''
        url=self.gh.pull_request(r.base_branch,branch,f'[Access] {r.access_level} - {r.resource_name or r.role}',body)
        return {'branch':branch,'url':url,'file':p.file_path}
