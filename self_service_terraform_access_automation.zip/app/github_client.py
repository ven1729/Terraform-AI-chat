from dataclasses import dataclass
from github import Github
from github.GithubException import GithubException
@dataclass
class TFFile:
    path:str; content:str
class GitHubClient:
    def __init__(self,token,owner,repo,api_url='https://api.github.com'):
        if not token or not owner or not repo: raise ValueError('GITHUB_TOKEN, GITHUB_OWNER and TARGET_REPO are required.')
        self.repo=Github(login_or_token=token,base_url=api_url).get_repo(f'{owner}/{repo}')
    def branch_sha(self,branch): return self.repo.get_branch(branch).commit.sha
    def branch_exists(self,branch):
        try: self.repo.get_branch(branch); return True
        except GithubException as e:
            if e.status==404:return False
            raise
    def tree_paths(self,branch):
        tree=self.repo.get_git_tree(self.branch_sha(branch),recursive=True)
        if getattr(tree,'truncated',False): raise RuntimeError('GitHub returned a truncated tree; refusing an incomplete scan.')
        return [x.path for x in tree.tree if x.type=='blob']
    def get_file(self,path,branch):
        x=self.repo.get_contents(path,ref=branch)
        if isinstance(x,list): raise RuntimeError(f'{path} is a directory.')
        return TFFile(path,x.decoded_content.decode('utf-8'))
    def terraform_files(self,branch):
        return [self.get_file(p,branch) for p in self.tree_paths(branch) if p.endswith('.tf') or p.endswith('.tfvars')]
    def create_branch(self,base,branch):
        if self.branch_exists(branch): raise RuntimeError(f'Branch already exists: {branch}')
        self.repo.create_git_ref(ref=f'refs/heads/{branch}',sha=self.branch_sha(base))
    def update_file(self,path,content,branch,message):
        x=self.repo.get_contents(path,ref=branch)
        if isinstance(x,list): raise RuntimeError(f'{path} is a directory.')
        self.repo.update_file(path=path,message=message,content=content,sha=x.sha,branch=branch)
    def pull_request(self,base,head,title,body): return self.repo.create_pull(title=title,body=body,head=head,base=base).html_url
