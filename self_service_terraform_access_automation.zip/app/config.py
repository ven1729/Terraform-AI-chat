from pathlib import Path
import json, os
from dotenv import load_dotenv
ROOT=Path(__file__).resolve().parents[1]

def settings():
    load_dotenv(ROOT/'.env')
    return {'github_token':os.getenv('GITHUB_TOKEN','').strip(),'github_owner':os.getenv('GITHUB_OWNER','').strip(),'target_repo':os.getenv('TARGET_REPO','').strip(),'target_branch':os.getenv('TARGET_BRANCH','main').strip() or 'main','github_api_url':os.getenv('GITHUB_API_URL','https://api.github.com').strip()}

def catalog():
    return json.loads((ROOT/'catalog/access_operations.json').read_text(encoding='utf-8'))
