class RepositoryScanner:
    def __init__(self,gh): self.gh=gh
    def scan(self,branch):
        files=self.gh.terraform_files(branch)
        dirs=sorted({f.path.rsplit('/',1)[0] for f in files if '/' in f.path})
        return {'terraform_file_count':len(files),'terraform_files':[{'path':f.path,'directory':f.path.rsplit('/',1)[0] if '/' in f.path else '.'} for f in files],'terraform_directories':dirs}
    def find(self,branch,pattern):
        matches=[f for f in self.gh.terraform_files(branch) if f.path==pattern or f.path.endswith('/'+pattern)]
        if not matches: raise FileNotFoundError(f'Target Terraform file not found: {pattern}')
        if len(matches)>1: raise RuntimeError('Ambiguous target file: '+', '.join(x.path for x in matches))
        return matches[0]
