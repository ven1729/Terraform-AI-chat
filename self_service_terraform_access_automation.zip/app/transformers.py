import re
class TfvarsTransformer:
    def append(self,content,var,value):
        m=re.search(rf'(?m)^[ \t]*{re.escape(var)}[ \t]*=[ \t*\[](?P<body>.*?)(?P<end>\])',content,re.DOTALL)
        if not m: raise ValueError(f"List variable '{var}' was not found in target tfvars file.")
        body=m.group('body')
        if value in re.findall(r'"([^"]*)"',body): return content,False
        indent='  '
        q=re.search(r'\n([ \t]*)"',body)
        if q: indent=q.group(1)
        insertion=body
        if body.strip() and not insertion.endswith('\n'): insertion+='\n'
        insertion+=f'{indent}"{value}",\n'
        return content[:m.start('body')]+insertion+content[m.end('body'):],True
class RbacTransformer:
    def append(self,content,role,scope,pid,ptype,name):
        marker=f'role_definition_name = "{role}"\n  principal_id         = "{pid}"'
        if marker in content:return content,False
        safe=re.sub(r'[^A-Za-z0-9_]+','_',name or role).strip('_').lower() or 'access'
        block=f'''\n\nresource "azurerm_role_assignment" "{safe}" {{\n  scope                = "{scope}"\n  role_definition_name = "{role}"\n  principal_id         = "{pid}"\n  principal_type       = "{ptype}"\n}}\n'''
        return content.rstrip()+block,True
