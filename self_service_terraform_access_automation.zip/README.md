# Self-Service Terraform Access Change Automation

Deterministic Streamlit MVP for converting repetitive access tickets into governed Terraform Pull Requests.

## Demo operations
- Cosmos DB managed identity Read / Read-Write access by appending an Object ID to configured tfvars lists.
- Generic Azure RBAC role assignment using an approved role catalog.

## Setup
```bash
python -m venv .venv
.venv\\Scripts\\activate
pip install -r requirements.txt
copy .env.example .env
streamlit run ui/streamlit_app.py
```

Edit `catalog/access_operations.json` to match the client's actual Terraform file paths and variable names.

Never commit `.env` or client credentials.

## Flow
Request -> Validate -> Recursive branch scan -> Duplicate check -> Terraform diff -> Working branch -> Commit -> Pull Request.
