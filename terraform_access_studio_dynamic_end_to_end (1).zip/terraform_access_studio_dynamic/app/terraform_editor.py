import re

def ensure_variable(text, name, description=None, variable_type="string"):
    if re.search(rf'variable\s+"{re.escape(name)}"\s*\{{', text):
        return text
    description = description or name.replace("_", " ").capitalize()
    block = f'\nvariable "{name}" {{\n  description = "{description}"\n  type        = {variable_type}\n}}\n'
    return (text.rstrip() + "\n" + block) if text.strip() else block.lstrip()

def set_tfvar(text, name, value):
    # Strings are HCL quoted values; keep GUIDs/IDs as strings.
    rendered = '"' + str(value).replace("\\", "\\\\").replace('"', '\\"') + '"'
    pattern = re.compile(rf'^\s*{re.escape(name)}\s*=.*$', re.M)
    line = f"{name} = {rendered}"
    if pattern.search(text):
        return pattern.sub(line, text, count=1)
    return text.rstrip() + ("\n" if text.strip() else "") + line + "\n"

def make_module_block(module_name, source, version, role_expression, scope_expression,
                      principal_expression, access_type, group_var, approver_var, principal_type):
    lines = [
        f'module "{module_name}" {{',
        f'  source  = "{source}"',
        f'  version = "{version}"',
        "",
        f"  role_definition = var.{role_expression}" if not role_expression.startswith("var.") else f"  role_definition = {role_expression}",
        f"  scope           = {scope_expression}",
    ]
    if access_type == "Managed Identity":
        lines += [
            f"  principal_id    = {principal_expression}",
            f'  principal_type  = "{principal_type}"',
        ]
    else:
        lines += [
            f"  group_object_id   = var.{group_var}",
            f"  approver_group_id = var.{approver_var}",
        ]
    lines.append("}")
    return "\n".join(lines) + "\n"

def append_module(main_text, block, module_name):
    if re.search(rf'module\s+"{re.escape(module_name)}"\s*\{{', main_text):
        raise ValueError(f"Module {module_name!r} already exists in main.tf. Choose a different request/ticket suffix.")
    return main_text.rstrip() + "\n\n# Added by Terraform Access Studio; review the plan before apply.\n" + block
