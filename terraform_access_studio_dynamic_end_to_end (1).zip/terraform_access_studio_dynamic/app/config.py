import os
from dotenv import load_dotenv

load_dotenv()

def get_config():
    return {
        "token": os.getenv("GITHUB_TOKEN", "").strip(),
        "owner": os.getenv("GITHUB_OWNER", "").strip(),
        "repo": os.getenv("TARGET_REPO", "").strip(),
        "branch": os.getenv("TARGET_BASE_BRANCH", "main").strip(),
        "api_url": os.getenv("GITHUB_API_URL", "https://api.github.com").rstrip("/"),
        "main_file": os.getenv("TARGET_MAIN_FILE", "main.tf").strip(),
        "outputs_file": os.getenv("TARGET_OUTPUTS_FILE", "outputs.tf").strip(),
        "variables_file": os.getenv("TARGET_VARIABLES_FILE", "variables.tf").strip(),
        "tfvars_pattern": os.getenv("TARGET_ENV_TFVARS_PATTERN", "env/{environment}/{environment}.tfvars").strip(),
    }
