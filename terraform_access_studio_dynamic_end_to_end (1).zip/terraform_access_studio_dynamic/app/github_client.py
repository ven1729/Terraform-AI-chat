import base64
import requests

class GitHubClient:
    def __init__(self, token, owner, repo, api_url="https://api.github.com"):
        self.token, self.owner, self.repo = token, owner, repo
        self.api_url = api_url.rstrip("/")
        self.headers = {
            "Authorization": f"Bearer {token}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
        }
        self.session = requests.Session()
        self.session.headers.update(self.headers)

    def _url(self, path):
        return f"{self.api_url}/repos/{self.owner}/{self.repo}/{path.lstrip('/')}"

    def _request(self, method, path, **kwargs):
        response = self.session.request(method, self._url(path), timeout=30, **kwargs)
        if not response.ok:
            try:
                detail = response.json().get("message", response.text)
            except Exception:
                detail = response.text
            raise RuntimeError(f"GitHub API {response.status_code}: {detail}")
        if response.status_code == 204:
            return None
        return response.json()

    def test_auth(self):
        response = self.session.get(f"{self.api_url}/user", timeout=20)
        if not response.ok:
            try: detail = response.json().get("message", response.text)
            except Exception: detail = response.text
            raise RuntimeError(f"GitHub authentication failed ({response.status_code}): {detail}")
        return response.json()

    def get_branch(self, branch):
        return self._request("GET", f"git/ref/heads/{branch.replace('/', '%2F')}")

    def get_tree(self, branch):
        ref = self.get_branch(branch)
        commit_sha = ref["object"]["sha"]
        commit = self._request("GET", f"git/commits/{commit_sha}")
        tree_sha = commit["tree"]["sha"]
        tree = self._request("GET", f"git/trees/{tree_sha}?recursive=1")
        return tree["tree"], commit_sha

    def get_file(self, path, ref):
        data = self._request("GET", f"contents/{path}", params={"ref": ref})
        if isinstance(data, list):
            raise RuntimeError(f"{path} is a directory, not a file.")
        return base64.b64decode(data["content"]).decode("utf-8"), data["sha"]

    def create_branch(self, branch_name, base_branch):
        base = self.get_branch(base_branch)
        self._request("POST", "git/refs", json={
            "ref": f"refs/heads/{branch_name}",
            "sha": base["object"]["sha"]
        })

    def put_file(self, path, content, branch, message, sha=None):
        import base64
        payload = {
            "message": message,
            "content": base64.b64encode(content.encode("utf-8")).decode("ascii"),
            "branch": branch,
        }
        if sha:
            payload["sha"] = sha
        return self._request("PUT", f"contents/{path}", json=payload)

    def create_pr(self, title, body, head, base):
        return self._request("POST", "pulls", json={
            "title": title, "body": body, "head": head, "base": base
        })
