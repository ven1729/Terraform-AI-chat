import re, time
from app.terraform_discovery import discover
from app.terraform_editor import ensure_variable, set_tfvar, make_module_block, append_module

ROLE_VAR_MAP = {
    "Key Vault Secrets Officer": "role_definition_keyvault_secret_officer",
    "Key Vault Contributor": "role_definition_keyvault_contributor",
    "Storage Blob Data Contributor": "role_definition_storage_blob_data_contributor",
    "Reader": "role_definition_name_reader",
}

class AccessWorkflow:
    def __init__(self, gh, config, module_catalog):
        self.gh, self.config, self.catalog = gh, config, module_catalog

    def scan(self, environment):
        tree, _ = self.gh.get_tree(self.config["branch"])
        paths = {item["path"] for item in tree if item.get("type") == "blob"}
        main_path = self.config["main_file"]
        out_path = self.config["outputs_file"]
        var_path = self.config["variables_file"]
        tfvars_path = self.config["tfvars_pattern"].format(environment=environment)
        # Find files by configured path; support common root/env layouts as fallback.
        def find_path(preferred, candidates):
            if preferred in paths: return preferred
            for candidate in candidates:
                if candidate in paths: return candidate
            matches = [p for p in paths if p.endswith("/" + preferred) or p == preferred]
            return matches[0] if len(matches) == 1 else preferred
        main_path = find_path(main_path, ["main.tf"])
        out_path = find_path(out_path, ["outputs.tf"])
        var_path = find_path(var_path, ["variables.tf"])
        tfvars_path = find_path(tfvars_path, [f"{environment}.tfvars", f"env/{environment}/{environment}.tfvars"])
        texts, shas = {}, {}
        for key, path in (("main.tf", main_path), ("outputs.tf", out_path), ("variables.tf", var_path), ("tfvars", tfvars_path)):
            try:
                texts[key], shas[path] = self.gh.get_file(path, self.config["branch"])
            except Exception as exc:
                # main.tf is required; missing other files are initialized empty so preview can explain it.
                if key == "main.tf": raise RuntimeError(f"Could not read required file {path}: {exc}")
                texts[key] = ""
        return {"paths": {"main.tf": main_path, "outputs.tf": out_path, "variables.tf": var_path, "tfvars": tfvars_path},
                "texts": texts, "shas": shas, "discovery": discover(texts)}

    def prepare(self, request):
        scanned = self.scan(request["environment"])
        # Preserve originals for safe diff rendering; never display full tfvars in the UI.
        scanned["original_texts"] = dict(scanned["texts"])
        d = scanned["discovery"]
        scope = next((x for x in d["scopes"] if x["expression"] == request["scope_expression"]), None)
        if not scope: raise ValueError("Selected scope is not in the latest repository scan.")
        principal = None
        if request["access_type"] == "Managed Identity":
            principal = next((x for x in d["principals"] if x["expression"] == request["principal_expression"]), None)
            if not principal: raise ValueError("Selected principal is not in the latest repository scan.")
        if request["access_type"] == "AD Group Access":
            for key in ("group_object_id", "approver_group_id"):
                if not re.fullmatch(r"[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}", request[key]):
                    raise ValueError(f"{key} must be a full GUID.")
        module_kind = "ad_group" if request["access_type"] == "AD Group Access" else "managed_identity"
        module_cfg = self.catalog["modules"][module_kind]
        role_var = request["role_variable"]
        if role_var not in d["variables"]:
            scanned["texts"]["variables.tf"] = ensure_variable(scanned["texts"]["variables.tf"], role_var, f"Role definition key for {request['role']}")
        role_value = self.catalog["roles"][request["role"]]["value"]
        scanned["texts"]["tfvars"] = set_tfvar(scanned["texts"]["tfvars"], role_var, role_value)
        for name, desc in [
            ("tenant_id", "Azure tenant ID"), ("subscription_id", "Azure subscription ID"),
            ("dpc_code", "DPC or application code"), ("eai_code", "EAI identifier"), ("environment", "Environment name")
        ]:
            scanned["texts"]["variables.tf"] = ensure_variable(scanned["texts"]["variables.tf"], name, desc)
        for name, value in [
            ("dpc_code", request["dpc_code"]), ("eai_code", request["eai_code"]),
            ("environment", request["environment"])
        ]:
            scanned["texts"]["tfvars"] = set_tfvar(scanned["texts"]["tfvars"], name, value)
        group_var, approver_var = "group_object_id", "approver_group_id"
        if request["access_type"] == "AD Group Access":
            for name, desc in [(group_var, "Microsoft Entra ID group object ID"), (approver_var, "Approver group object ID")]:
                scanned["texts"]["variables.tf"] = ensure_variable(scanned["texts"]["variables.tf"], name, desc)
            scanned["texts"]["tfvars"] = set_tfvar(scanned["texts"]["tfvars"], group_var, request["group_object_id"])
            scanned["texts"]["tfvars"] = set_tfvar(scanned["texts"]["tfvars"], approver_var, request["approver_group_id"])
            principal_expr = ""
        else:
            principal_expr = request["principal_expression"]
        module_name = f"{module_cfg['prefix']}_{re.sub(r'[^A-Za-z0-9_-]+','-',request['ticket']).lower()}"
        block = make_module_block(module_name, module_cfg["source"], module_cfg["version"], role_var,
                                  request["scope_expression"], principal_expr, request["access_type"],
                                  group_var, approver_var, request.get("principal_type", "ServicePrincipal"))
        scanned["texts"]["main.tf"] = append_module(scanned["texts"]["main.tf"], block, module_name)
        scanned["module_name"] = module_name
        scanned["request"] = request
        scanned["role_value"] = role_value
        # Names only: do not pass actual tfvars values to the UI.
        def assignment_map(text):
            return {
                m.group(1): m.group(2).strip()
                for m in re.finditer(r'^\\s*([A-Za-z_][A-Za-z0-9_]*)\\s*=\\s*(.*?)\\s*$', text or "", re.M)
            }
        before_map = assignment_map(scanned["original_texts"].get("tfvars", ""))
        after_map = assignment_map(scanned["texts"]["tfvars"])
        scanned["tfvars_changed_keys"] = sorted(
            name for name in set(before_map) | set(after_map)
            if before_map.get(name) != after_map.get(name)
        )
        return scanned

    def publish(self, prepared):
        ticket = re.sub(r"[^A-Za-z0-9-]+", "-", prepared["request"]["ticket"]).lower()
        branch = f"feature/access-{ticket}-{int(time.time())}"
        base = self.config["branch"]
        self.gh.create_branch(branch, base)
        paths, texts, shas = prepared["paths"], prepared["texts"], prepared["shas"]
        changes = []
        for key in ("main.tf", "variables.tf", "tfvars"):
            path = paths[key]
            original = self.gh.get_file(path, base)[1] if path in shas else None
            if key == "tfvars" and not original:
                # new tfvars file; parent directories are created by GitHub Contents API
                original = None
            self.gh.put_file(path, texts[key], branch, f"Add access automation for {prepared['request']['ticket']}", sha=original)
            changes.append(path)
        body = (
            "## Terraform access request\n\n"
            f"- **Ticket:** {prepared['request']['ticket']}\n"
            f"- **Environment:** {prepared['request']['environment']}\n"
            f"- **Access type:** {prepared['request']['access_type']}\n"
            f"- **Role:** {prepared['request']['role']}\n"
            f"- **Scope expression:** `{prepared['request']['scope_expression']}`\n"
            f"- **Principal:** `{prepared['request'].get('principal_expression','AD group IDs')}`\n\n"
            "Generated by Terraform Access Studio. Review the diff, run `terraform fmt` and `terraform validate`, "
            "then inspect a Terraform plan before merging. This PR does not apply infrastructure changes.\n"
        )
        pr = self.gh.create_pr(f"[{prepared['request']['ticket']}] Terraform access assignment", body, branch, base)
        return {"branch": branch, "pr_url": pr["html_url"], "files": changes}
