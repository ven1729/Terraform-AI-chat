from __future__ import annotations
from datetime import datetime, timezone
import re
from app.config import settings, catalog
from app.github_client import GitHubClient
from app.models import AccessRequest, ChangePreview, FileChange, ValidationResult
from app.scanner import RepositoryScanner
from app.terraform_editor import (
    build_group_module, build_managed_identity_module,
    ensure_string_assignment, ensure_variable_block
)

GUID = re.compile(
    r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-"
    r"[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
)

class Workflow:
    def __init__(self):
        self.cfg = settings()
        self.cat = catalog()
        self.github = GitHubClient(
            self.cfg["github_token"], self.cfg["github_owner"],
            self.cfg["target_repo"], self.cfg["github_api_url"]
        )
        self.scanner = RepositoryScanner(self.github)

    def validate(self, request):
        errors, warnings = [], []
        if request.access_type not in {"managed_identity", "ad_group"}:
            errors.append("Unsupported access type.")
        if request.resource_type not in self.cat["resources"]:
            errors.append("Unsupported resource type.")
        role_cfg = self.cat["roles"].get(request.role)
        if not role_cfg:
            errors.append("Selected role is not in the approved IAM role catalog.")
        elif role_cfg["scope_resource"] not in {"any", request.resource_type}:
            errors.append(f"Role '{request.role}' is not configured for this resource.")
        for label, value in [
            ("Environment", request.environment),
            ("DPC code", request.dpc_code),
            ("EAI code", request.eai_code),
            ("Ticket ID", request.ticket_id),
        ]:
            if not value.strip():
                errors.append(f"{label} is required.")
        if request.access_type == "managed_identity":
            if request.principal_source not in self.cat["principal_sources"]:
                errors.append("Select an approved managed identity source.")
        else:
            if not GUID.fullmatch(request.group_object_id or ""):
                errors.append("AD Group Object ID must be a valid GUID.")
            if not GUID.fullmatch(request.approver_group_id or ""):
                errors.append("Approver Group ID must be a valid GUID.")
        return ValidationResult(not errors, errors, warnings)

    def analyze(self, request):
        tfvars_path = self.cfg["tfvars_pattern"].format(environment=request.environment)
        return self.scanner.scan(
            self.cfg["base_branch"], self.cfg["main_file"],
            self.cfg["variables_file"], tfvars_path
        )

    def _module_name(self, request):
        prefix = self.cat["iam_modules"][request.access_type]["module_prefix"]
        ticket = re.sub(r"[^0-9A-Za-z]+", "_", request.ticket_id).strip("_").lower()
        resource = re.sub(r"[^0-9A-Za-z]+", "_", request.resource_type).strip("_").lower()
        return f"{prefix}_{resource}_{ticket or 'access'}"

    def preview(self, request):
        snapshot = self.analyze(request)
        role_cfg = self.cat["roles"][request.role]
        resource_cfg = self.cat["resources"][request.resource_type]
        module_name = self._module_name(request)

        if request.access_type == "managed_identity":
            module_cfg = self.cat["iam_modules"]["managed_identity"]
            main_after, main_changed = build_managed_identity_module(
                snapshot.main_content, module_name, module_cfg["source"],
                module_cfg["version"], role_cfg["variable"],
                resource_cfg["scope_expression"],
                self.cat["principal_sources"][request.principal_source]
            )
        else:
            module_cfg = self.cat["iam_modules"]["ad_group"]
            main_after, main_changed = build_group_module(
                snapshot.main_content, module_name, module_cfg["source"],
                module_cfg["version"], role_cfg["variable"],
                resource_cfg["scope_expression"]
            )

        # Every value referenced by the generated IAM module must have a
        # corresponding Terraform variable declaration.  The selected role is
        # especially important: the catalog maps the human-readable role to
        # the exact variable name expected by the module pattern.
        variables_after = snapshot.variables_content
        variables_changed = False
        required_variables = [
            "tenant_id",
            "subscription_id",
            "dpc_code",
            "eai_code",
            "environment",
            role_cfg["variable"],
        ]

        if request.access_type == "managed_identity":
            variables_after, changed = ensure_variable_block(variables_after, "principal_type")
            variables_changed |= changed
        else:
            for name in ["group_object_id", "approver_group_id"]:
                variables_after, changed = ensure_variable_block(variables_after, name)
                variables_changed |= changed

        for name in required_variables:
            variables_after, changed = ensure_variable_block(variables_after, name)
            variables_changed |= changed

        # Write the request-specific values to the environment tfvars file.
        # tenant_id and subscription_id are intentionally not invented here;
        # they remain whatever the target repository already defines unless
        # the UI is extended to collect them explicitly.
        tfvars_after = snapshot.tfvars_content
        tfvars_changed = False
        for name, value in [
            ("dpc_code", request.dpc_code),
            ("eai_code", request.eai_code),
            ("environment", request.environment),
            (role_cfg["variable"], request.role),
        ]:
            tfvars_after, changed = ensure_string_assignment(tfvars_after, name, value)
            tfvars_changed |= changed

        if request.access_type == "managed_identity":
            tfvars_after, changed = ensure_string_assignment(
                tfvars_after, "principal_type",
                self.cat["variable_defaults"]["principal_type"]
            )
            tfvars_changed |= changed
        else:
            for name, value in [
                ("group_object_id", request.group_object_id),
                ("approver_group_id", request.approver_group_id)
            ]:
                tfvars_after, changed = ensure_string_assignment(tfvars_after, name, value)
                tfvars_changed |= changed

        changes = [
            FileChange(snapshot.main_path, snapshot.main_content, main_after, main_changed,
                       "Add approved IAM module call."),
            FileChange(snapshot.variables_path, snapshot.variables_content, variables_after,
                       variables_changed, "Ensure IAM variables exist."),
            FileChange(snapshot.tfvars_path, snapshot.tfvars_content, tfvars_after,
                       tfvars_changed, "Apply request values to environment tfvars.")
        ]
        count = sum(c.changed for c in changes)
        return ChangePreview(changes, module_name,
                             f"{count} Terraform file(s) will change using the approved IAM module pattern.")

    def publish(self, request, preview):
        changed = [c for c in preview.changes if c.changed]
        if not changed:
            raise RuntimeError("No Terraform change is required.")
        base = self.cfg["base_branch"]
        ticket = re.sub(r"[^0-9A-Za-z]+", "-", request.ticket_id).strip("-").lower()
        branch = f"feature/access-{ticket}-{datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')}"
        self.github.create_branch(base, branch)
        for c in changed:
            self.github.update_file(c.path, c.after, branch,
                                     f"chore(access): {request.role} - {request.ticket_id}")
        body = (
            f"## Terraform Access Change\n\n"
            f"**Ticket:** `{request.ticket_id}`\n\n"
            f"**Access type:** `{request.access_type}`\n\n"
            f"**Resource:** `{self.cat['resources'][request.resource_type]['label']}`\n\n"
            f"**Environment:** `{request.environment}`\n\n"
            f"**Role:** `{request.role}`\n\n"
            f"**IAM module:** `{preview.module_name}`\n\n"
            "### Changed files\n"
            + "\n".join(f"- `{c.path}`" for c in changed)
            + "\n\nThe base branch was not modified directly. Review the generated Terraform through the pull request.\n"
        )
        url = self.github.create_pull_request(
            base, branch, f"[Access] {request.role} - {request.ticket_id}", body
        )
        return {"branch": branch, "url": url}
