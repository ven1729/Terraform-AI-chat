# Self-Service Terraform Access Automation — IAM MVP

This MVP converts an approved access request entered in Streamlit into a complete Terraform change and a GitHub pull request.

## What it generates

For **AD Group Access**, the application generates/updates all of the coordinated Terraform pieces:

- `main.tf` — approved IAM group-role-assignment module call
- `variables.tf` — common variables, the selected role variable, `group_object_id`, and `approver_group_id`
- `env/<environment>/<environment>.tfvars` — selected role value, group object ID, approver group ID, DPC, EAI and environment

For **Managed Identity Access**, it generates/updates:

- `main.tf` — approved IAM role-assignment module call
- `variables.tf` — common variables, selected role variable and `principal_type`
- environment `.tfvars` — selected role value, principal type, DPC, EAI and environment

`tenant_id` and `subscription_id` are declared and preserved from the target repository. The MVP does not invent those values because they are not collected by the UI.

## Architecture

```text
Streamlit UI
    |
    v
AccessRequest
    |
    v
Catalog validation
    |
    v
Recursive GitHub branch scan
    |
    v
Deterministic Terraform editor
    |
    +--> main.tf
    +--> variables.tf
    +--> env/<environment>/<environment>.tfvars
    |
    v
Feature branch
    |
    v
Pull Request
```

## Run

```powershell
python -m venv .venv
.venv\\Scripts\\activate
pip install -r requirements.txt
copy .env.example .env
streamlit run ui/streamlit_app.py
```

## Demo request

Use:

- Access type: AD Group Access
- Target resource: Key Vault
- Role: Key Vault Contributor
- Environment: `dv-0001`
- DPC: `14972`
- EAI: `EAI-DEMO`
- Ticket: `REQ-DEMO-001`
- Group Object ID: `11111111-1111-1111-1111-111111111111`
- Approver Group ID: `22222222-2222-2222-2222-222222222222`

The preview should show changes to all three Terraform files.

## Important

This is an MVP. Before production use, add `terraform fmt`, `terraform validate`, `terraform plan`, policy/security checks, HCL-aware editing, GitHub least-privilege credentials, SSO/RBAC, approval gates and audit logging.
