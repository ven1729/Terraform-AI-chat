# Terraform Access Studio — Fresh End-to-End MVP

A Streamlit self-service UI that reads a configured GitHub Terraform repository, discovers candidate resource scopes and principal expressions, supports multiple IAM access assignments, previews Terraform changes, and creates one pull request. It **does not run `terraform apply`**.

## What's corrected in this version

- Resolves `.env` by absolute path beside this `README.md`, not the terminal's current working directory.
- Reads values from this project's `.env` first, then falls back to environment variables. This avoids a stale shell variable silently selecting a different repository.
- Shows a safe diagnostics panel with the `.env` path, API base URL, whether a token is loaded, and configured repository names. It never prints the token.
- Displays the exact failed GitHub API endpoint and status code without exposing authorization headers.
- Uses the same REST API path for repository details and branch listing as the successful PowerShell tests.
- Keeps the selectable repository list as an explicit allow-list in `.env`.

## 1. Requirements

- Python 3.10+
- GitHub repository containing Terraform files such as `main.tf`, `outputs.tf`, `variables.tf`, and environment `.tfvars` files.
- A GitHub token with repository access. For this MVP, the token needs Contents read/write and Pull requests read/write, plus Metadata read. Organization approval may be required.

## 2. Setup (PowerShell)

Extract the ZIP, open PowerShell in the extracted `terraform_access_studio_fresh` folder, then run:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
notepad .env
```

Set the actual token in `.env` and configure the allowed repository. Example:

```env
GITHUB_TOKEN=YOUR_TOKEN
GITHUB_REPOSITORIES_JSON='[{"owner":"ven1729","repo":"terraform-ai-chat","label":"terraform-ai-chat"}]'
GITHUB_API_URL=https://api.github.com
TARGET_BASE_BRANCH=main
TARGET_MAIN_FILE=main.tf
TARGET_OUTPUTS_FILE=outputs.tf
TARGET_VARIABLES_FILE=variables.tf
TARGET_ENV_TFVARS_PATTERN=env/{environment}/{environment}.tfvars
```

Do not include `.git` in the repository name. Never commit or share `.env`.

## 3. Run

From the same project folder:

```powershell
streamlit run ui/streamlit_app.py
```

If you change `.env`, stop Streamlit with `Ctrl+C` and run it again. Open **Configuration diagnostics** in the app to confirm the `.env` path and selected repository.

## 4. Workflow

1. Choose an allow-listed GitHub repository.
2. The app loads its branches and default branch.
3. Select a base branch and environment discovered from tfvars paths.
4. Review detected Terraform modules, scopes, principals, and variables.
5. Add one or more AD group / managed identity assignments and choose approved roles.
6. Validate and inspect the proposed `main.tf`, `variables.tf`, and environment `.tfvars` diffs.
7. Create one feature branch and one pull request for the whole request.

## 5. Important implementation limitations

- Discovery uses conservative regular expressions, not a full HCL parser. Review every generated expression.
- Validate internal IAM module source addresses, versions, variable names, role-key semantics, and tfvars conventions against your organization's approved modules before use.
- This MVP does not run `terraform fmt`, `terraform validate`, policy checks, or `terraform plan`; CI should do that before merge.
- It does not apply infrastructure changes. A reviewer must inspect the PR and plan before merging.
- For production, add approval gates, audit logging, least-privilege access, tests, and concurrency controls.

## 6. 404 troubleshooting

The error now includes the exact URL. Compare it with the successful PowerShell request. Confirm the safe diagnostics panel reports the intended repository, `ven1729/terraform-ai-chat`, and `https://api.github.com`. If the URL is correct and PowerShell succeeds, confirm the `.env` token belongs to the same account/token used in PowerShell and has access to the selected repository. Never paste the token into logs or chat.
