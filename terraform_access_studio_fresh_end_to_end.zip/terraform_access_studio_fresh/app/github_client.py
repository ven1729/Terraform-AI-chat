"""Small GitHub REST client with endpoint-aware, token-safe errors."""
import base64
from urllib.parse import quote
import requests


class GitHubClient:
    def __init__(self, token, owner, repo, api_url="https://api.github.com"):
        self.token = (token or "").strip()
        self.owner = (owner or "").strip()
        self.repo = (repo or "").strip().removesuffix(".git")
        self.api_url = (api_url or "https://api.github.com").strip().rstrip("/")
        if not self.token:
            raise RuntimeError("GITHUB_TOKEN is empty. Check the project .env file and restart Streamlit.")
        if not self.owner or not self.repo:
            raise RuntimeError("GitHub owner/repository is empty. Check GITHUB_REPOSITORIES_JSON in .env.")
        self.headers = {
            "Authorization": f"Bearer {self.token}",
            "Accept": "application/vnd.github+json",
            "X-GitHub-Api-Version": "2022-11-28",
            "User-Agent": "Terraform-Access-Studio",
        }
        self.session = requests.Session()
        self.session.headers.update(self.headers)

    def _repo_url(self, path=""):
        owner = quote(self.owner, safe="")
        repo = quote(self.repo, safe="")
        suffix = path.lstrip("/")
        base = f"{self.api_url}/repos/{owner}/{repo}"
        return f"{base}/{suffix}" if suffix else base

    def _request(self, method, path="", **kwargs):
        url = self._repo_url(path)
        try:
            response = self.session.request(method, url, timeout=30, **kwargs)
        except requests.RequestException as exc:
            raise RuntimeError(f"Could not connect to GitHub API at {url}: {exc.__class__.__name__}: {exc}") from exc
        if not response.ok:
            try:
                payload = response.json()
                detail = payload.get("message", response.text) if isinstance(payload, dict) else response.text
            except ValueError:
                detail = response.text
            # Never include request headers or token in exceptions.
            raise RuntimeError(
                f"GitHub API {response.status_code} on {method.upper()} {response.url}: {detail}. "
                "Check the owner/repository, API URL, token access, and token permissions."
            )
        if response.status_code == 204 or not response.content:
            return None
        return response.json()

    def test_auth(self):
        url = f"{self.api_url}/user"
        try:
            response = self.session.get(url, timeout=20)
        except requests.RequestException as exc:
            raise RuntimeError(f"Could not connect to GitHub authentication endpoint: {exc.__class__.__name__}: {exc}") from exc
        if not response.ok:
            try:
                detail = response.json().get("message", response.text)
            except ValueError:
                detail = response.text
            raise RuntimeError(f"GitHub authentication failed ({response.status_code}) at {url}: {detail}")
        return response.json()

    def get_repo(self):
        return self._request("GET")

    def list_branches(self):
        branches, page = [], 1
        while page <= 10:
            batch = self._request("GET", "branches", params={"per_page": 100, "page": page})
            if not isinstance(batch, list):
                raise RuntimeError("GitHub branches endpoint returned an unexpected response format.")
            branches.extend(item["name"] for item in batch if isinstance(item, dict) and item.get("name"))
            if len(batch) < 100:
                break
            page += 1
        return sorted(set(branches), key=str.casefold)

    def get_branch(self, branch):
        # Branch names may contain slashes. GitHub expects the ref path encoded.
        return self._request("GET", f"git/ref/heads/{quote(branch, safe='/')}")

    def get_tree(self, branch):
        ref = self.get_branch(branch)
        commit_sha = ref["object"]["sha"]
        commit = self._request("GET", f"git/commits/{quote(commit_sha, safe='')}")
        tree_sha = commit["tree"]["sha"]
        tree = self._request("GET", f"git/trees/{quote(tree_sha, safe='')}", params={"recursive": "1"})
        return tree["tree"], commit_sha

    def get_file(self, path, ref):
        encoded_path = "/".join(quote(part, safe="") for part in path.split("/"))
        data = self._request("GET", f"contents/{encoded_path}", params={"ref": ref})
        if isinstance(data, list):
            raise RuntimeError(f"{path} is a directory, not a file.")
        if data.get("encoding") != "base64" or "content" not in data:
            raise RuntimeError(f"GitHub did not return base64 file content for {path}.")
        return base64.b64decode(data["content"]).decode("utf-8"), data["sha"]

    def create_branch(self, branch_name, base_branch):
        base = self.get_branch(base_branch)
        self._request("POST", "git/refs", json={"ref": f"refs/heads/{branch_name}", "sha": base["object"]["sha"]})

    def put_file(self, path, content, branch, message, sha=None):
        encoded_path = "/".join(quote(part, safe="") for part in path.split("/"))
        payload = {"message": message, "content": base64.b64encode(content.encode("utf-8")).decode("ascii"), "branch": branch}
        if sha:
            payload["sha"] = sha
        return self._request("PUT", f"contents/{encoded_path}", json=payload)

    def create_pr(self, title, body, head, base):
        return self._request("POST", "pulls", json={"title": title, "body": body, "head": head, "base": base})
