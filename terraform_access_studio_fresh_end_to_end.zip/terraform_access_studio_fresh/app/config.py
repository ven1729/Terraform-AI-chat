"""Configuration loader for Terraform Access Studio.

The .env path is resolved relative to this file, not the shell's current directory.
This avoids Streamlit accidentally loading a different .env when launched elsewhere.
"""
import json
import os
from pathlib import Path
from dotenv import dotenv_values

PROJECT_ROOT = Path(__file__).resolve().parents[1]
ENV_FILE = PROJECT_ROOT / ".env"

def get_config():
    """Load local .env values first, falling back to process environment variables.

    Prefer the .env beside this project so a stale shell variable or a different
    working directory cannot silently point the UI at another repository.
    """
    file_values = dotenv_values(ENV_FILE) if ENV_FILE.exists() else {}

    def setting(name, default=""):
        value = file_values.get(name)
        if value is not None and str(value).strip() != "":
            return str(value).strip()
        return os.getenv(name, default).strip()

    token = setting("GITHUB_TOKEN")
    api_url = setting("GITHUB_API_URL", "https://api.github.com").rstrip("/")
    if not api_url:
        api_url = "https://api.github.com"

    repositories = []
    raw = setting("GITHUB_REPOSITORIES_JSON")
    if raw:
        try:
            parsed = json.loads(raw)
            if not isinstance(parsed, list):
                raise ValueError("GITHUB_REPOSITORIES_JSON must be a JSON list")
            for item in parsed:
                if not isinstance(item, dict):
                    continue
                owner = str(item.get("owner", "")).strip()
                repo = str(item.get("repo", "")).strip()
                if owner and repo:
                    repositories.append({
                        "owner": owner,
                        "repo": repo,
                        "label": str(item.get("label") or f"{owner}/{repo}").strip(),
                    })
        except (json.JSONDecodeError, ValueError) as exc:
            raise RuntimeError(f"Invalid GITHUB_REPOSITORIES_JSON in {ENV_FILE}: {exc}") from exc

    if not repositories:
        owner = setting("GITHUB_OWNER")
        repo = setting("TARGET_REPO")
        if owner and repo:
            repositories = [{"owner": owner, "repo": repo, "label": f"{owner}/{repo}"}]

    # De-duplicate entries by owner/repo while preserving configured order.
    unique = []
    seen = set()
    for item in repositories:
        key = (item["owner"].casefold(), item["repo"].casefold())
        if key not in seen:
            unique.append(item)
            seen.add(key)

    return {
        "token": token,
        "api_url": api_url,
        "repositories": unique,
        "env_file": str(ENV_FILE),
        "default_branch": setting("TARGET_BASE_BRANCH", "main") or "main",
        "main_file": setting("TARGET_MAIN_FILE", "main.tf") or "main.tf",
        "outputs_file": setting("TARGET_OUTPUTS_FILE", "outputs.tf") or "outputs.tf",
        "variables_file": setting("TARGET_VARIABLES_FILE", "variables.tf") or "variables.tf",
        "tfvars_pattern": setting("TARGET_ENV_TFVARS_PATTERN", "env/{environment}/{environment}.tfvars"),
    }
