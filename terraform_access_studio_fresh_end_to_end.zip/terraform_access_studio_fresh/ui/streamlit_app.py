import difflib
import json
import re
import sys
from pathlib import Path

import streamlit as st

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from app.config import get_config
from app.github_client import GitHubClient
from app.workflow import AccessWorkflow

st.set_page_config(page_title="Terraform Access Studio", page_icon="🔐", layout="wide")
st.markdown("""
<style>
.stApp {background:linear-gradient(135deg,#f3f8ff 0%,#f8f4ff 55%,#effcf8 100%)}
.block-container {padding-top:1.3rem;max-width:1500px}
.hero {padding:1.4rem 1.6rem;border-radius:22px;color:white;background:linear-gradient(110deg,#263b8f,#6554c0,#008c95);margin-bottom:1rem}
.hero h1 {color:white;margin:0;font-size:2.1rem}.hero p {color:#edf5ff;margin:.35rem 0 0}
div[data-testid="stMetric"] {background:white;border:1px solid #dbe5f4;padding:1rem;border-radius:16px}
div.stButton>button {border-radius:12px;font-weight:700;min-height:2.65rem}
.assignment-card {background:#ffffffa8;border:1px solid #dce5f5;border-radius:16px;padding:12px 16px;margin:8px 0}
</style>
<div class="hero"><h1>🔐 Terraform Access Studio</h1><p>Select a repository, base branch and environment. Build multiple AD-group and managed-identity role assignments, review every Terraform/tfvars diff, and create one pull request.</p></div>
""", unsafe_allow_html=True)

try:
    config = get_config()
except Exception as exc:
    st.error(f"Could not load configuration: {exc}")
    st.info("Confirm that .env is in the same folder as README.md and restart Streamlit.")
    st.stop()

with st.expander("Configuration diagnostics (safe; token is never displayed)", expanded=False):
    st.write("Project .env path:", config["env_file"])
    st.write("GitHub API URL:", config["api_url"])
    st.write("Token loaded:", bool(config["token"]))
    st.write("Configured repositories:", [f"{r['owner']}/{r['repo']}" for r in config["repositories"]])

if not config["token"] or not config["repositories"]:
    st.error("Configuration is incomplete. Set GITHUB_TOKEN and GITHUB_REPOSITORIES_JSON in the project-root .env file.")
    st.code('GITHUB_REPOSITORIES_JSON=\'[ {"owner":"ven1729","repo":"terraform-ai-chat","label":"terraform-ai-chat"} ]\'')
    st.stop()

catalog = json.loads((ROOT / "catalog/access_catalog.json").read_text(encoding="utf-8"))
repo_options = {item["label"]: item for item in config["repositories"]}
default_repo_label = next(iter(repo_options))
if st.session_state.get("repo_label") not in repo_options:
    st.session_state.repo_label = default_repo_label

st.markdown("### 1 · Repository, branch and environment")
repo_col, branch_col, env_col = st.columns([1.5, 1.2, 1.0])
with repo_col:
    repo_label = st.selectbox("GitHub repository", list(repo_options), key="repo_label")
selected_repo = repo_options[repo_label]
repo_key = f"{selected_repo['owner']}/{selected_repo['repo']}"

@st.cache_data(ttl=120, show_spinner=False)
def fetch_branches(token, owner, repo, api_url):
    return GitHubClient(token, owner, repo, api_url).list_branches()

@st.cache_data(ttl=120, show_spinner=False)
def fetch_repo_default(token, owner, repo, api_url):
    return GitHubClient(token, owner, repo, api_url).get_repo().get("default_branch", "main")

try:
    with st.spinner(f"Connecting to GitHub and loading branches for {repo_key}…"):
        branches = fetch_branches(config["token"], selected_repo["owner"], selected_repo["repo"], config["api_url"])
        repo_default = fetch_repo_default(config["token"], selected_repo["owner"], selected_repo["repo"], config["api_url"])
except Exception as exc:
    st.error(f"Could not load branches for {repo_key}.")
    st.code(str(exc))
    with st.expander("Troubleshooting", expanded=True):
        st.write("1. Compare the endpoint above with the successful PowerShell URL.")
        st.write("2. Confirm the project .env path and selected repository in Configuration diagnostics.")
        st.write("3. Stop Streamlit with Ctrl+C and restart it from this project folder.")
        st.write("4. Do not paste your token into chat or logs.")
    st.stop()
if not branches:
    st.error("No branches were returned for this repository.")
    st.stop()
branch_state_key = f"branch_for_{repo_key}"
if st.session_state.get(branch_state_key) not in branches:
    st.session_state[branch_state_key] = repo_default if repo_default in branches else (config["default_branch"] if config["default_branch"] in branches else branches[0])
with branch_col:
    selected_branch = st.selectbox("Base branch", branches, key=branch_state_key, help="The selected branch is scanned and used as the pull request target.")

client_key = (repo_key, selected_branch)
if st.session_state.get("active_target") != client_key:
    st.session_state.active_target = client_key
    st.session_state.scan_result = None
    st.session_state.prepared = None
    st.session_state.environments = None
    st.session_state.env_choice = None

try:
    gh = GitHubClient(config["token"], selected_repo["owner"], selected_repo["repo"], config["api_url"])
    wf = AccessWorkflow(gh, {**config, "owner": selected_repo["owner"], "repo": selected_repo["repo"]}, catalog, base_branch=selected_branch)
    if st.session_state.get("environments") is None:
        st.session_state.environments = wf.list_environments()
    environments = st.session_state.environments or []
except Exception as exc:
    st.error(f"Could not inspect {repo_key}@{selected_branch}: {exc}")
    st.stop()
if not environments:
    environments = ["dev", "qa", "prod"]
    st.caption("No environment tfvars files were detected on this branch. Choose an environment to create/use its configured tfvars path.")
with env_col:
    default_env = "dv-0001" if "dv-0001" in environments else environments[0]
    if st.session_state.get("env_choice") not in environments:
        st.session_state.env_choice = default_env
    environment = st.selectbox("Environment / tfvars", environments, key="env_choice")

control1, control2, control3 = st.columns([1, 1, 2])
with control1:
    if st.button("🔎 Scan selected target", use_container_width=True):
        try:
            st.session_state.scan_result = wf.scan(environment)
            st.session_state.prepared = None
            st.success(f"Scanned {repo_key} · {selected_branch} · {environment}")
        except Exception as exc:
            st.error(f"Repository scan failed: {exc}")
with control2:
    if st.button("Clear preview", use_container_width=True):
        st.session_state.prepared = None
        st.rerun()
with control3:
    st.info(f"**Target:** `{repo_key}` · **Base:** `{selected_branch}` · **Environment:** `{environment}`")

if st.session_state.get("scan_result") is None or st.session_state.scan_result.get("environment") != environment or st.session_state.scan_result.get("base_branch") != selected_branch:
    try:
        st.session_state.scan_result = wf.scan(environment)
        st.session_state.prepared = None
    except Exception as exc:
        st.error(f"Repository scan could not complete: {exc}")
        st.stop()
scan = st.session_state.scan_result
disc = scan["discovery"]
m1, m2, m3, m4 = st.columns(4)
m1.metric("Terraform modules", len(disc["modules"]))
m2.metric("Discovered scopes", len(disc["scopes"]))
m3.metric("Discovered principals", len(disc["principals"]))
m4.metric("Existing variables", len(disc["variables"]))
with st.expander("Discovered repository objects", expanded=False):
    left, right = st.columns(2)
    with left:
        st.subheader("Scopes")
        st.dataframe([{"Choice": x["label"], "Expression": x["expression"], "Source": x["source_file"], "Confidence": x["confidence"]} for x in disc["scopes"]], use_container_width=True, hide_index=True)
    with right:
        st.subheader("Managed identities / principals")
        st.dataframe([{"Choice": x["label"], "Expression": x["expression"], "Source": x["source_file"], "Confidence": x["confidence"]} for x in disc["principals"]], use_container_width=True, hide_index=True)

st.markdown("## 2 · Build access assignments")
st.caption("Each assignment can have one principal, one resource scope and multiple roles. Add as many assignments as needed; the tool creates one pull request for the complete request.")
if "assignment_count" not in st.session_state:
    st.session_state.assignment_count = 2
add_col, remove_col, spacer_col = st.columns([1, 1, 3])
with add_col:
    if st.button("＋ Add assignment", use_container_width=True):
        st.session_state.assignment_count = min(20, st.session_state.assignment_count + 1)
        st.session_state.prepared = None
        st.rerun()
with remove_col:
    if st.button("－ Remove last", disabled=st.session_state.assignment_count <= 1, use_container_width=True):
        st.session_state.assignment_count -= 1
        st.session_state.prepared = None
        st.rerun()

role_names = list(catalog["roles"].keys())
scope_options = {x["label"]: x["expression"] for x in disc["scopes"]}
principal_options = {x["label"]: x["expression"] for x in disc["principals"]}
assignments = []
for idx in range(st.session_state.assignment_count):
    with st.container(border=True):
        st.markdown(f"### Assignment {idx + 1}")
        c1, c2, c3 = st.columns([1, 1.2, 1.2])
        with c1:
            label = st.text_input("Assignment label", value=f"access_{idx + 1}", key=f"a_{idx}_label")
            access_type = st.selectbox("Principal type", ["AD Group Access", "Managed Identity"], key=f"a_{idx}_type")
        with c2:
            if scope_options:
                scope_label = st.selectbox("Resource scope", list(scope_options), key=f"a_{idx}_scope")
                scope_expression = scope_options[scope_label]
                st.code(scope_expression, language="hcl")
            else:
                st.warning("No scopes were detected in the selected branch.")
                scope_expression = ""
        with c3:
            roles = st.multiselect("IAM roles", role_names, key=f"a_{idx}_roles", help="Every selected role becomes a role-assignment module instance.")
            if access_type == "Managed Identity":
                if principal_options:
                    principal_label = st.selectbox("Managed identity / principal", list(principal_options), key=f"a_{idx}_principal")
                    principal_expression = principal_options[principal_label]
                else:
                    st.warning("No principal expressions detected. Expose a principal ID in outputs.tf or main.tf.")
                    principal_expression = ""
                principal_type = st.selectbox("Azure principal type", ["ServicePrincipal", "Group", "User"], key=f"a_{idx}_principal_type")
                group_id, approver_id = "", ""
            else:
                principal_expression, principal_type = "", "ServicePrincipal"
                group_id = st.text_input("AD group Object ID (GUID)", key=f"a_{idx}_group_id")
                approver_id = st.text_input("Approver group Object ID (GUID)", key=f"a_{idx}_approver_id")
        assignments.append({"label": label.strip() or f"assignment_{idx + 1}", "access_type": access_type,
                            "scope_expression": scope_expression, "roles": roles, "principal_expression": principal_expression,
                            "principal_type": principal_type, "group_object_id": group_id, "approver_group_id": approver_id})

st.markdown("## 3 · Request metadata")
meta1, meta2, meta3 = st.columns(3)
with meta1:
    ticket = st.text_input("Request / ticket ID", value="REQ-DEMO-001", key="ticket_id")
with meta2:
    dpc_code = st.text_input("DPC code", value="14972", key="dpc_code")
with meta3:
    eai_code = st.text_input("EAI code", value="EAI-DEMO", key="eai_code")

st.warning("This tool creates a feature branch and pull request only. It does not run terraform apply. Review module input names and run terraform fmt, terraform validate and terraform plan before merging.")
current_request = {"ticket": ticket.strip(), "environment": environment, "dpc_code": dpc_code.strip(), "eai_code": eai_code.strip(),
                   "assignments": assignments, "repository": repo_key, "base_branch": selected_branch}
if st.button("🧪 Validate and preview all changes", type="primary", use_container_width=True):
    try:
        if not ticket.strip():
            raise ValueError("Enter a request / ticket ID.")
        st.session_state.prepared = wf.prepare(current_request)
        st.success("Validation passed. Review every generated diff below.")
    except Exception as exc:
        st.session_state.prepared = None
        st.error(str(exc))

prepared = st.session_state.get("prepared")
if prepared:
    preview_matches = json.dumps(prepared.get("input_request", {}), sort_keys=True) == json.dumps(current_request, sort_keys=True)
    if not preview_matches:
        st.warning("Your request inputs have changed since this preview was generated. Validate and preview again before creating a pull request.")
    st.subheader(f"Preview · {len(prepared['module_names'])} IAM module instance(s)")
    st.caption(f"Repository: {repo_key} · base branch: {selected_branch} · environment: {environment}. AD group IDs and role values are shown in tfvars diffs; credential-like values are masked.")

    def redact_secret_like_tfvars(text):
        secret_name = re.compile(r"(password|secret|token|client_secret|private_key|access_key|connection_string|sas_token)", re.I)
        lines = []
        for line in (text or "").splitlines(keepends=True):
            match = re.match(r"^(\s*)([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)(\r?\n)?$", line)
            if match and secret_name.search(match.group(2)):
                lines.append(f'{match.group(1)}{match.group(2)} = "[REDACTED]"{match.group(4) or ""}')
            else:
                lines.append(line)
        return "".join(lines)

    originals = prepared.get("original_texts", {})
    preview_files = [("main.tf", "main.tf changes", True), ("variables.tf", "variables.tf changes", False),
                     ("tfvars", f"Environment tfvars changes — {prepared['paths'].get('tfvars', 'tfvars')}", True)]
    for key, title, expanded in preview_files:
        before, after = originals.get(key, ""), prepared["texts"].get(key, "")
        if key == "tfvars":
            before, after = redact_secret_like_tfvars(before), redact_secret_like_tfvars(after)
        diff = "".join(difflib.unified_diff(before.splitlines(keepends=True), after.splitlines(keepends=True),
                                            fromfile=f"before/{title}", tofile=f"after/{title}"))
        with st.expander(title, expanded=expanded):
            st.code(diff or "No changes.", language="diff")
    st.markdown("#### Assignment summary")
    st.dataframe([{"Assignment": a["label"], "Principal type": a["access_type"], "Roles": ", ".join(a["roles"]),
                   "Scope": a["scope_expression"], "Principal expression": a.get("principal_expression") or "AD group Object ID in tfvars"}
                  for a in prepared["request"]["assignments"]], use_container_width=True, hide_index=True)
    if st.button("🚀 Create one GitHub pull request", type="primary", disabled=not preview_matches, use_container_width=True):
        try:
            # Rebuild a client and workflow from the currently selected repository and branch.
            result = wf.publish(prepared)
            st.success(f"Pull request created: {result['pr_url']}")
            st.link_button("Open pull request", result["pr_url"], use_container_width=True)
            st.write("Changed files:", ", ".join(result["files"]))
            st.write("Created branch:", result["branch"])
        except Exception as exc:
            st.error(f"Could not create pull request: {exc}")
