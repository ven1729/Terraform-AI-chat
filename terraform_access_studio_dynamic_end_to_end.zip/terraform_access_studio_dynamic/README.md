# Terraform Access Studio — Dynamic IAM Self-Service MVP

A deterministic Streamlit app that scans a GitHub Terraform repository, discovers candidate IAM scope and principal expressions from `main.tf` and `outputs.tf`, ensures role/group variables exist, previews the changes, and opens a pull request. It does **not** run `terraform apply`.

## Important note about your internal IAM modules

The sample module sources and input names in `catalog/access_catalog.json` and `app/terraform_editor.py` are examples based on the shared repository structure. Verify the exact required inputs for your approved private Terraform modules before use. In particular, confirm whether your module expects `role_definition`, `scope`, `principal_id`, `principal_type`, `group_object_id`, and `approver_group_id`, and whether the role variable's tfvars value should be the role key string or another value.

## 1. Requirements

- Python 3.10+
- A GitHub repository containing `main.tf`, `outputs.tf` (optional), `variables.tf` (optional), and an environment tfvars file.
- A GitHub token with access to the target repository:
  - Contents: Read and write
  - Pull requests: Read and write
  - Metadata: Read
- Organization policies may require fine-grained token approval.

## 2. Install

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
```

Edit `.env` with the owner, repository, token, branch, and file paths. Never commit `.env`.

```env
GITHUB_TOKEN=YOUR_TOKEN
GITHUB_OWNER=your-org
TARGET_REPO=your-terraform-repo
TARGET_BASE_BRANCH=main
GITHUB_API_URL=https://api.github.com
TARGET_MAIN_FILE=main.tf
TARGET_OUTPUTS_FILE=outputs.tf
TARGET_VARIABLES_FILE=variables.tf
TARGET_ENV_TFVARS_PATTERN=env/{environment}/{environment}.tfvars
```

## 3. Run

From the project root:

```powershell
streamlit run ui/streamlit_app.py
```

The app validates the token, scans the configured branch, and displays detected scope/principal candidates. Choose a scope, access type, role, environment, and ticket. Click **Validate and preview changes** before **Create GitHub pull request**.

## 4. Discovery behavior

- Reads configured root `main.tf`, `outputs.tf`, `variables.tf`, and environment `.tfvars`.
- Scans module output references and existing IAM module blocks for candidate scopes and principals.
- Shows the source file and confidence description for detected expressions.
- Keeps dynamic expressions as Terraform expressions rather than trying to resolve Azure runtime IDs.
- Uses a catalog for approved IAM module source/version and role keys. That catalog is intentionally separate from discovered resource/principal expressions.
- The app creates a feature branch, commits modified files, and opens a PR against the configured base branch.

## 5. Limitations / review checklist

1. Terraform HCL parsing here uses conservative regular expressions, not a full HCL parser. Complex nested blocks, heredocs, and unusual formatting may need a proper HCL parser before production use.
2. Discovery is heuristic. A resource/module output named `*_id` may be a valid scope candidate but must be reviewed by a Terraform owner. The app does not know Azure RBAC semantics solely from a variable name.
3. The demo `outputs.tf` shows typical output patterns. In a real repository, configure the actual paths and check that outputs are exposed at the root module.
4. The app creates a PR but does not run `terraform fmt`, `terraform validate`, policy checks, or `terraform plan`. Add required CI checks and branch protection.
5. Before production, add tests, audit logging, environment allowlists, ticket-system validation, approvals, concurrency controls, and least-privilege token handling.
6. This MVP assumes one `main.tf`, one `variables.tf`, and one tfvars file for the selected environment. It does not yet intelligently edit arbitrary module files or remote module source code.

## 6. GitHub 401 troubleshooting

- Test the token without sharing it:
  ```powershell
  $token = Read-Host "Enter GitHub token"
  $headers = @{ Authorization = "Bearer $token"; Accept = "application/vnd.github+json"; "X-GitHub-Api-Version" = "2022-11-28" }
  Invoke-RestMethod -Uri "https://api.github.com/user" -Headers $headers
  ```
- If this fails with 401, create a new token and check that it was copied completely.
- If it succeeds but the app fails, remove a stale environment override in the current PowerShell session:
  ```powershell
  Remove-Item Env:GITHUB_TOKEN -ErrorAction SilentlyContinue
  ```
  Restart Streamlit after changing `.env`.
- For fine-grained tokens, confirm the correct resource owner, repository selection, permissions, and organization approval.
