import json, os, sys
from pathlib import Path
import streamlit as st

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from app.config import get_config
from app.github_client import GitHubClient
from app.workflow import AccessWorkflow

st.set_page_config(page_title="Terraform Access Studio", page_icon="🔐", layout="wide")
st.markdown("""
<style>
.stApp {background: linear-gradient(135deg,#f3f8ff 0%,#f8f4ff 55%,#effcf8 100%);}
.block-container {padding-top: 1.6rem; max-width: 1450px;}
.hero {padding: 1.4rem 1.6rem; border-radius: 22px; color: white;
background: linear-gradient(110deg,#263b8f,#6554c0,#008c95); margin-bottom: 1rem;}
.hero h1 {color:white; margin:0; font-size:2.15rem;}
.hero p {color:#edf5ff; margin:.35rem 0 0 0;}
div[data-testid="stMetric"] {background:white; border:1px solid #dbe5f4; padding:1rem; border-radius:16px;}
div.stButton > button {border-radius:12px; font-weight:700; min-height:2.8rem;}
section[data-testid="stSidebar"] {background:#eef3ff;}
</style>
<div class="hero"><h1>🔐 Terraform Access Studio</h1>
<p>Discover Terraform scopes and managed identities from your repository, preview the exact edits, and open a pull request.</p></div>
""", unsafe_allow_html=True)

config = get_config()
with st.sidebar:
    st.header("GitHub connection")
    st.caption("Values load from .env. Never paste your token into the app or share it in chat.")
    owner = st.text_input("GitHub owner / organization", value=config["owner"])
    repo = st.text_input("Target repository", value=config["repo"])
    branch = st.text_input("Base branch", value=config["branch"])
    token = st.text_input("GitHub token", value=config["token"], type="password")
    api_url = st.text_input("GitHub API URL", value=config["api_url"])
    st.divider()
    st.caption("The token needs repository Contents read/write and Pull requests read/write permissions.")

config.update({"owner": owner.strip(), "repo": repo.strip(), "branch": branch.strip(), "token": token.strip(), "api_url": api_url.strip()})
ready = all(config[k] for k in ("token", "owner", "repo", "branch"))
if not ready:
    st.warning("Complete the GitHub connection fields in the sidebar or configure your .env file.")
    st.stop()

try:
    gh = GitHubClient(config["token"], config["owner"], config["repo"], config["api_url"])
except Exception as e:
    st.error(str(e)); st.stop()

if "scan_result" not in st.session_state:
    st.session_state.scan_result = None
if "prepared" not in st.session_state:
    st.session_state.prepared = None

col1, col2, col3 = st.columns([1,1,2])
with col1:
    if st.button("🔎 Scan repository", use_container_width=True):
        try:
            user = gh.test_auth()
            wf = AccessWorkflow(gh, config, json.loads((ROOT / "catalog/access_catalog.json").read_text()))
            env = st.session_state.get("environment", "dv-0001")
            st.session_state.scan_result = wf.scan(env)
            st.session_state.prepared = None
            st.success(f"Authenticated as {user.get('login','GitHub user')}; repository scan complete.")
        except Exception as e:
            st.session_state.scan_result = None
            st.error(str(e))
with col2:
    if st.button("Clear preview", use_container_width=True):
        st.session_state.prepared = None
        st.rerun()
with col3:
    st.info(f"Target: **{owner}/{repo}** · branch **{branch}**")

# Scan once on initial load too, so the user sees available choices.
if st.session_state.scan_result is None:
    try:
        wf = AccessWorkflow(gh, config, json.loads((ROOT / "catalog/access_catalog.json").read_text()))
        st.session_state.scan_result = wf.scan(st.session_state.get("environment", "dv-0001"))
    except Exception as e:
        st.error(f"Repository scan could not complete: {e}")
        st.stop()

scan = st.session_state.scan_result
disc = scan["discovery"]
m1,m2,m3,m4 = st.columns(4)
m1.metric("Terraform modules", len(disc["modules"]))
m2.metric("Discovered scopes", len(disc["scopes"]))
m3.metric("Discovered principals", len(disc["principals"]))
m4.metric("Existing variables", len(disc["variables"]))
with st.expander("Discovered repository objects", expanded=False):
    a,b = st.columns(2)
    with a:
        st.subheader("Scopes")
        st.dataframe([{"Choice":x["label"],"Expression":x["expression"],"Source":x["source_file"],"Confidence":x["confidence"]} for x in disc["scopes"]], use_container_width=True, hide_index=True)
    with b:
        st.subheader("Managed identities / principals")
        st.dataframe([{"Choice":x["label"],"Expression":x["expression"],"Source":x["source_file"],"Confidence":x["confidence"]} for x in disc["principals"]], use_container_width=True, hide_index=True)

st.markdown("## Create an access request")
left, right = st.columns(2, gap="large")
with left:
    st.markdown("### 1 · Request details")
    access_type = st.radio("Access type", ["Managed Identity", "AD Group Access"], horizontal=True)
    environment = st.text_input("Environment folder / name", value=st.session_state.get("environment", "dv-0001"), key="environment")
    ticket = st.text_input("Request / ticket ID", value="REQ-DEMO-001")
    dpc_code = st.text_input("DPC code", value="14972")
    eai_code = st.text_input("EAI code", value="EAI-DEMO")
    role_names = list(json.loads((ROOT / "catalog/access_catalog.json").read_text())["roles"].keys())
    role = st.selectbox("Azure role", role_names)
    role_variable = json.loads((ROOT / "catalog/access_catalog.json").read_text())["roles"][role]["value"]
    st.caption(f"Terraform role variable: `{role_variable}`")
with right:
    st.markdown("### 2 · Scope and principal")
    scopes = disc["scopes"]
    if not scopes:
        st.warning("No scope expressions detected. Check main.tf and outputs.tf are in the configured branch.")
        scope_expression = ""
    else:
        scope_map = {x["label"]: x["expression"] for x in scopes}
        scope_label = st.selectbox("Target scope", list(scope_map))
        scope_expression = scope_map[scope_label]
        st.code(scope_expression, language="hcl")
    principal_expression = ""
    group_object_id = approver_group_id = ""
    principal_type = "ServicePrincipal"
    if access_type == "Managed Identity":
        principals = disc["principals"]
        if not principals:
            st.warning("No principal IDs were detected. Expose a principal ID in outputs.tf or use an existing principal_id reference in main.tf.")
        else:
            pmap = {x["label"]: x["expression"] for x in principals}
            plabel = st.selectbox("Managed identity / principal", list(pmap))
            principal_expression = pmap[plabel]
        principal_type = st.selectbox("Principal type", ["ServicePrincipal", "User", "Group"], index=0)
    else:
        group_object_id = st.text_input("AD group Object ID (GUID)")
        approver_group_id = st.text_input("Approver group Object ID (GUID)")

st.markdown("### 3 · Preview and publish")
st.warning("This tool creates a branch and pull request only. It does not run terraform apply. Review module input names and run terraform fmt, validate, and plan before merging.")
if st.button("🧪 Validate and preview changes", type="primary", use_container_width=True):
    try:
        if not scope_expression: raise ValueError("Select a target scope.")
        if access_type == "Managed Identity" and not principal_expression: raise ValueError("Select a principal.")
        wf = AccessWorkflow(gh, config, json.loads((ROOT / "catalog/access_catalog.json").read_text()))
        request = {
            "access_type": access_type, "environment": environment.strip(), "ticket": ticket.strip(),
            "dpc_code": dpc_code.strip(), "eai_code": eai_code.strip(), "role": role,
            "role_variable": role_variable, "scope_expression": scope_expression,
            "principal_expression": principal_expression, "principal_type": principal_type,
            "group_object_id": group_object_id.strip(), "approver_group_id": approver_group_id.strip(),
        }
        st.session_state.prepared = wf.prepare(request)
        st.success("Validation passed. Review the generated diff below.")
    except Exception as e:
        st.session_state.prepared = None
        st.error(str(e))

prepared = st.session_state.prepared
if prepared:
    st.subheader(f"Preview: module `{prepared['module_name']}`")
    for key, title in [("main.tf","main.tf"),("variables.tf","variables.tf"),("tfvars",prepared["paths"]["tfvars"])]:
        with st.expander(f"Preview {title}", expanded=(key=="main.tf")):
            st.code(prepared["texts"][key], language="hcl")
    st.caption("Preview is generated from the latest scan. Confirm the target branch is correct before opening a PR.")
    if st.button("🚀 Create GitHub pull request", type="primary", use_container_width=True):
        try:
            result = AccessWorkflow(gh, config, json.loads((ROOT / "catalog/access_catalog.json").read_text())).publish(prepared)
            st.success(f"Pull request created: {result['pr_url']}")
            st.link_button("Open pull request", result["pr_url"], use_container_width=True)
            st.write("Changed files:", ", ".join(result["files"]))
        except Exception as e:
            st.error(f"Could not create pull request: {e}")
