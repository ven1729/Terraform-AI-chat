# Self-Service Terraform Access Automation — IAM Demo

Deterministic, no-AI MVP that converts an approved access request into Terraform changes and a GitHub pull request.

## IAM patterns

Managed identity:
- `app.terraform.io/MetLife-Global/iam-role-assignment/azurerm`
- version `3.0.1`
- `principal_id`
- `principal_type`
- `role_definition_name`
- resource module output as `scope`

AD group:
- `app.terraform.io/MetLife-Global/iam-group-role-assignment/azurerm`
- version `1.0.6`
- `group_object_id`
- `approver_group_id`
- `role_definition_name`
- resource module output as `scope`

## Roles represented from the supplied examples

- Key Vault Secrets Officer
- Key Vault Contributor
- Storage Blob Data Contributor
- Reader

## Resource expressions represented from the supplied examples

- Key Vault: `module.key-vault.keyvault_id[0]`
- Storage/ADLS: `module.storage-account.storageaccount_id[0]`
- ADF managed identity: `module.azurerm_data_factory.Datafactory_Managed_Identity_Principal_ID`
- Databricks access connector:
  `module.azurerm_databricks_workspace.databricks_access_connector_managed_identity_principal_id`

The catalog is explicit. Add only verified production mappings.

## Run

```bash
python -m venv .venv
```

Windows:
```powershell
.venv\Scripts\activate
```

```bash
pip install -r requirements.txt
```

Create `.env`:
```env
GITHUB_TOKEN=<your-personal-github-token>
GITHUB_OWNER=<your-github-username>
TARGET_REPO=<your-demo-repository>
TARGET_BASE_BRANCH=demo-access-automation
```

Run:
```bash
streamlit run ui/streamlit_app.py
```

## Demo repository

The included `demo_target_repo` contains:
```text
main.tf
variables.tf
env/
└── dv-0001/
    └── dv-0001.tfvars
```

Push it to your personal GitHub repo and create `demo-access-automation`.

## Workflow

1. Select AD Group or Managed Identity.
2. Select resource and approved role.
3. Enter environment, DPC, EAI and ticket.
4. Enter AD/approver IDs for AD-group access or choose an approved managed identity.
5. Analyze branch.
6. Preview changes to `main.tf`, `variables.tf` and environment tfvars.
7. Create feature branch.
8. Commit changes.
9. Open PR.

## Production hardening

Use client secret management, least-privilege GitHub credentials, Terraform fmt/validate/plan, policy checks, HCL-aware editing, SSO/RBAC, audit logging, ownership/approval gates and CI checks. Do not put real secrets or sensitive production identifiers in a public demo repository.
