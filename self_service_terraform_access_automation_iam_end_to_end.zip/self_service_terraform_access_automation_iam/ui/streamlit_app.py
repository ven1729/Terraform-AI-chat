from __future__ import annotations
import difflib
import sys
from pathlib import Path
import streamlit as st

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from app.config import catalog, settings
from app.models import AccessRequest
from app.workflow import Workflow

st.set_page_config(page_title="Terraform Access Automation", page_icon="🔐", layout="wide")

st.markdown("""
<style>
.stApp{background:#0b1220;color:#e5e7eb}
.block-container{max-width:1200px;padding-top:2rem}
.hero{padding:26px 30px;border:1px solid #263449;border-radius:18px;background:linear-gradient(135deg,#111c2e,#0e1726);margin-bottom:22px}
.hero .kicker{color:#60a5fa;font-size:13px;font-weight:700;letter-spacing:.08em;text-transform:uppercase}
.hero h1{margin:5px 0 8px;color:#f8fafc;font-size:36px}
.hero p{color:#94a3b8;margin:0}
.card{padding:16px 18px;border:1px solid #263449;border-radius:15px;background:#111827;margin-bottom:15px}
.badge{display:inline-block;padding:5px 9px;border-radius:999px;background:#172554;color:#93c5fd;font-size:12px;font-weight:700}
</style>
""", unsafe_allow_html=True)

cat = catalog()
cfg = settings()

st.markdown("""
<div class="hero">
<div class="kicker">Infrastructure Engineering Workspace</div>
<h1>Self-Service Terraform Access Automation</h1>
<p>Convert approved access requests into reviewable Terraform pull requests.</p>
</div>
""", unsafe_allow_html=True)

with st.sidebar:
    st.markdown("### Deployment Console")
    if cfg["github_owner"] and cfg["target_repo"]:
        st.markdown(
            f'<div class="card"><b>{cfg["github_owner"]}/{cfg["target_repo"]}</b>'
            f'<br>Base: {cfg["base_branch"]}</div>', unsafe_allow_html=True
        )
    else:
        st.error("Configure .env before running.")
    st.caption("Request → Analyze → Preview → PR")

st.subheader("1. Define access request")
access_label = st.radio("Access type", ["AD Group Access", "Managed Identity Access"], horizontal=True)
access_type = "ad_group" if access_label == "AD Group Access" else "managed_identity"

resource_type = st.selectbox(
    "Target resource", list(cat["resources"]),
    format_func=lambda x: cat["resources"][x]["label"]
)
roles = [r for r, m in cat["roles"].items() if m["scope_resource"] in {"any", resource_type}]
role = st.selectbox("Approved access role", roles)

c1, c2, c3 = st.columns(3)
with c1:
    environment = st.text_input("Environment", "dv-0001")
with c2:
    dpc_code = st.text_input("DPC code", "14972")
with c3:
    eai_code = st.text_input("EAI code", "")

ticket_id = st.text_input("Service ticket / request ID", "REQ-DEMO-001")

principal_source = None
group_object_id = None
approver_group_id = None

if access_type == "managed_identity":
    principal_source = st.selectbox("Approved managed identity", list(cat["principal_sources"]))
    st.caption("Terraform principal expressions are resolved from the approved catalog.")
else:
    c1, c2 = st.columns(2)
    with c1:
        group_object_id = st.text_input("AD Group Object ID")
    with c2:
        approver_group_id = st.text_input("Approver Group ID")

request = AccessRequest(
    access_type=access_type, resource_type=resource_type, role=role,
    environment=environment, dpc_code=dpc_code, eai_code=eai_code,
    ticket_id=ticket_id, principal_source=principal_source,
    group_object_id=group_object_id, approver_group_id=approver_group_id
)

if st.button("Validate request", use_container_width=True):
    try:
        result = Workflow().validate(request)
        if result.ok:
            st.success("Request passed catalog validation.")
        else:
            for e in result.errors:
                st.error(e)
    except Exception as exc:
        st.error(str(exc))

st.subheader("2. Analyze target branch")
if st.button("Analyze repository", use_container_width=True):
    try:
        wf = Workflow()
        validation = wf.validate(request)
        if not validation.ok:
            for e in validation.errors:
                st.error(e)
        else:
            snapshot = wf.analyze(request)
            st.session_state["workflow"] = wf
            st.session_state["snapshot"] = snapshot
            st.success("Repository analysis completed.")
    except Exception as exc:
        st.error(str(exc))

if "snapshot" in st.session_state:
    s = st.session_state["snapshot"]
    a, b, c, d = st.columns(4)
    a.metric("Terraform files", len(s.files))
    b.metric("Module calls", len(s.module_calls))
    c.metric("Variables", len(s.variables))
    d.metric("Target tfvars", s.tfvars_path)
    with st.expander("Discovered Terraform files"):
        st.write(s.files)
    with st.expander("Detected module calls"):
        st.write(s.module_calls)

st.subheader("3. Preview exact Terraform change")
if st.button("Generate change preview", type="primary", use_container_width=True):
    try:
        wf = st.session_state.get("workflow") or Workflow()
        validation = wf.validate(request)
        if not validation.ok:
            for e in validation.errors:
                st.error(e)
        else:
            preview = wf.preview(request)
            st.session_state["workflow"] = wf
            st.session_state["preview"] = preview
            st.success(preview.summary)
    except Exception as exc:
        st.error(str(exc))

if "preview" in st.session_state:
    p = st.session_state["preview"]
    st.markdown(f'<span class="badge">Approved IAM module</span> <b>{p.module_name}</b>',
                unsafe_allow_html=True)
    for change in p.changes:
        with st.expander(
            f"{'CHANGED' if change.changed else 'UNCHANGED'} · {change.path}",
            expanded=change.changed
        ):
            diff = "".join(difflib.unified_diff(
                change.before.splitlines(True), change.after.splitlines(True),
                fromfile=f"{change.path} (before)", tofile=f"{change.path} (after)"
            ))
            st.code(diff or "No change required.", language="diff")

st.subheader("4. Create feature branch + pull request")
st.warning("The base branch is never edited directly by this application.")
if st.button("Create feature branch + pull request", type="primary", use_container_width=True):
    try:
        wf = st.session_state.get("workflow") or Workflow()
        preview = st.session_state.get("preview")
        if not preview:
            st.error("Generate the preview first.")
        else:
            result = wf.publish(request, preview)
            st.success("Pull request created.")
            st.code(result["branch"])
            st.link_button("Open Pull Request", result["url"])
    except Exception as exc:
        st.error(str(exc))

st.caption(
    "MVP follows the IAM module patterns shown in the supplied Terraform examples. "
    "Before production use, add terraform fmt/validate/plan, policy checks, stronger HCL parsing, SSO/RBAC and audit logging."
)
