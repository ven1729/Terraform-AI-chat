from __future__ import annotations
import re

def module_exists(main, module_name):
    pattern = r'^\s*module\s+"' + re.escape(module_name) + r'"\s*\{'
    return bool(re.search(pattern, main, flags=re.MULTILINE))

def append_block(text, block):
    return text.rstrip() + "\n\n" + block.strip() + "\n"

def ensure_variable_block(variables_tf, variable_name):
    pattern = r'^\s*variable\s+"' + re.escape(variable_name) + r'"\s*\{'
    if re.search(pattern, variables_tf, flags=re.MULTILINE):
        return variables_tf, False
    return append_block(variables_tf, f'variable "{variable_name}" {{}}'), True

def ensure_string_assignment(tfvars, variable_name, value):
    pattern = re.compile(
        rf'^(\s*{re.escape(variable_name)}\s*=\s*)(".*?"|[^#\n]+)(\s*(?:#.*)?)$',
        re.MULTILINE
    )
    match = pattern.search(tfvars)
    if match:
        if match.group(2).strip() == f'"{value}"':
            return tfvars, False
        replacement = rf'\1"{value}"\3'
        return tfvars[:match.start()] + replacement + tfvars[match.end():], True
    return append_block(tfvars, f'{variable_name} = "{value}"'), True

def build_managed_identity_module(main, module_name, source, version,
                                  role_variable, scope_expression, principal_expression):
    if module_exists(main, module_name):
        return main, False
    block = f'''module "{module_name}" {{
  source  = "{source}"
  version = "{version}"

  tenant_id       = var.tenant_id
  subscription_id = var.subscription_id
  dpc_code        = var.dpc_code
  eai_code        = var.eai_code
  environment     = var.environment

  role_definition_name = var.{role_variable}
  scope                = {scope_expression}
  principal_id         = {principal_expression}
  principal_type       = var.principal_type

  custom_tags = {{
    SCM_COMMIT_ID = var.TFC_CONFIGURATION_VERSION_GIT_COMMIT_SHA
  }}
}}'''
    return append_block(main, block), True

def build_group_module(main, module_name, source, version,
                       role_variable, scope_expression):
    if module_exists(main, module_name):
        return main, False
    block = f'''module "{module_name}" {{
  source  = "{source}"
  version = "{version}"

  tenant_id       = var.tenant_id
  subscription_id = var.subscription_id
  dpc_code        = var.dpc_code
  eai_code        = var.eai_code
  environment     = var.environment

  role_definition_name = var.{role_variable}
  scope                = {scope_expression}
  group_object_id      = var.group_object_id
  approver_group_id    = var.approver_group_id

  custom_tags = {{
    SCM_COMMIT_ID = var.TFC_CONFIGURATION_VERSION_GIT_COMMIT_SHA
  }}
}}'''
    return append_block(main, block), True
