from __future__ import annotations
import json
import os
from pathlib import Path
from dotenv import load_dotenv

ROOT = Path(__file__).resolve().parents[1]
load_dotenv(ROOT / ".env")

def settings():
    return {
        "github_token": os.getenv("GITHUB_TOKEN", "").strip(),
        "github_owner": os.getenv("GITHUB_OWNER", "").strip(),
        "target_repo": os.getenv("TARGET_REPO", "").strip(),
        "base_branch": os.getenv("TARGET_BASE_BRANCH", "main").strip(),
        "github_api_url": os.getenv("GITHUB_API_URL", "https://api.github.com").strip(),
        "main_file": os.getenv("TARGET_MAIN_FILE", "main.tf").strip(),
        "variables_file": os.getenv("TARGET_VARIABLES_FILE", "variables.tf").strip(),
        "tfvars_pattern": os.getenv("TARGET_ENV_TFVARS_PATTERN",
                                    "env/{environment}/{environment}.tfvars").strip(),
    }

def catalog():
    with open(ROOT / "catalog" / "access_catalog.json", encoding="utf-8") as f:
        return json.load(f)
