from dataclasses import dataclass, field
from typing import List, Optional

@dataclass
class AccessRequest:
    access_type: str
    resource_type: str
    role: str
    environment: str
    dpc_code: str
    eai_code: str
    ticket_id: str
    principal_source: Optional[str] = None
    group_object_id: Optional[str] = None
    approver_group_id: Optional[str] = None
    principal_type: str = "ServicePrincipal"

@dataclass
class ValidationResult:
    ok: bool
    errors: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)

@dataclass
class FileChange:
    path: str
    before: str
    after: str
    changed: bool
    reason: str

@dataclass
class ChangePreview:
    changes: List[FileChange]
    module_name: str
    summary: str
