from __future__ import annotations
import base64
from github import Github
from github.GithubException import GithubException

class GitHubClient:
    def __init__(self, token, owner, repo_name, api_url):
        if not token:
            raise ValueError("GITHUB_TOKEN is not configured.")
        if not owner or not repo_name:
            raise ValueError("GITHUB_OWNER and TARGET_REPO are required.")
        self.github = Github(base_url=api_url, login_or_token=token)
        self.repo = self.github.get_repo(f"{owner}/{repo_name}")

    def get_branch_sha(self, branch):
        return self.repo.get_branch(branch).commit.sha

    def get_tree(self, branch):
        tree = self.repo.get_git_tree(self.get_branch_sha(branch), recursive=True)
        if getattr(tree, "truncated", False):
            raise RuntimeError("GitHub returned a truncated tree; refusing incomplete discovery.")
        return [{"path": x.path, "type": x.type, "sha": x.sha} for x in tree.tree]

    def list_files(self, branch, extensions=(".tf", ".tfvars")):
        return sorted(
            x["path"] for x in self.get_tree(branch)
            if x["type"] == "blob" and x["path"].lower().endswith(extensions)
        )

    def read_file(self, path, branch):
        obj = self.repo.get_contents(path, ref=branch)
        if isinstance(obj, list):
            raise ValueError(f"{path} is a directory.")
        return base64.b64decode(obj.content).decode("utf-8")

    def create_branch(self, base_branch, new_branch):
        try:
            self.repo.get_branch(new_branch)
            raise ValueError(f"Branch already exists: {new_branch}")
        except GithubException as exc:
            if exc.status != 404:
                raise
        self.repo.create_git_ref(
            ref=f"refs/heads/{new_branch}",
            sha=self.get_branch_sha(base_branch),
        )

    def update_file(self, path, content, branch, message):
        obj = self.repo.get_contents(path, ref=branch)
        if isinstance(obj, list):
            raise ValueError(f"{path} is a directory.")
        result = self.repo.update_file(
            path=path, message=message, content=content, sha=obj.sha, branch=branch
        )
        return result["commit"].sha

    def create_pull_request(self, base, head, title, body):
        return self.repo.create_pull(title=title, body=body, head=head, base=base).html_url
