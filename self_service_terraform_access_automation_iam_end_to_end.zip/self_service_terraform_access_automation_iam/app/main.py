from app.config import settings

def main():
    cfg = settings()
    print("Self-Service Terraform Access Automation")
    print(f"Target repository: {cfg['github_owner']}/{cfg['target_repo']}")
    print(f"Base branch: {cfg['base_branch']}")

if __name__ == "__main__":
    main()
