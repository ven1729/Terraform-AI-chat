from __future__ import annotations
import re
from dataclasses import dataclass

MODULE_RE = re.compile(r'^\s*module\s+"([^"]+)"\s*\{', re.MULTILINE)
VARIABLE_RE = re.compile(r'^\s*variable\s+"([^"]+)"\s*\{', re.MULTILINE)

@dataclass
class RepoSnapshot:
    branch: str
    files: list
    main_path: str
    variables_path: str
    tfvars_path: str
    main_content: str
    variables_content: str
    tfvars_content: str
    module_calls: list
    variables: list

class RepositoryScanner:
    def __init__(self, github_client):
        self.github = github_client

    @staticmethod
    def find_file(files, wanted):
        if wanted in files:
            return wanted
        matches = [p for p in files if p.split("/")[-1] == wanted]
        return matches[0] if len(matches) == 1 else None

    def scan(self, branch, main_file, variables_file, tfvars_path):
        files = self.github.list_files(branch)
        main_path = self.find_file(files, main_file)
        variables_path = self.find_file(files, variables_file)
        if not main_path:
            raise FileNotFoundError(f"Could not find {main_file} on branch {branch}.")
        if not variables_path:
            raise FileNotFoundError(f"Could not find {variables_file} on branch {branch}.")
        if tfvars_path not in files:
            matches = [p for p in files if p.split("/")[-1] == tfvars_path.split("/")[-1]]
            if len(matches) != 1:
                raise FileNotFoundError(f"Could not find environment tfvars file: {tfvars_path}")
            tfvars_path = matches[0]

        main = self.github.read_file(main_path, branch)
        variables = self.github.read_file(variables_path, branch)
        tfvars = self.github.read_file(tfvars_path, branch)
        return RepoSnapshot(
            branch=branch, files=files, main_path=main_path,
            variables_path=variables_path, tfvars_path=tfvars_path,
            main_content=main, variables_content=variables, tfvars_content=tfvars,
            module_calls=MODULE_RE.findall(main), variables=VARIABLE_RE.findall(variables)
        )
