# Terraform Access Studio — Dynamic IAM Self-Service MVP

A deterministic Streamlit app that scans a GitHub Terraform repository, discovers candidate IAM scope and principal expressions from `main.tf` and `outputs.tf`, ensures role/group variables exist, previews the changes, and opens a pull request. It does **not** run `terraform apply`.

## Important note about your internal IAM modules

The sample module sources and input names in `catalog/access_catalog.json` and `app/terraform_editor.py` are examples based on the shared repository structure. Verify the exact required inputs for your approved private Terraform modules before use. In particular, confirm whether your module expects `role_definition`, `scope`, `principal_id`, `principal_type`, `group_object_id`, and `approver_group_id`, and whether the role variable's tfvars value should be the role key string or another value.

## 1. Requirements

- Python 3.10+
- A GitHub repository containing `main.tf`, `outputs.tf` (optional), `variables.tf` (optional), and an environment tfvars file.
- A GitHub token with access to the target repository:
  - Contents: Read and write
  - Pull requests: Read and write
  - Metadata: Read
- Organization policies may require fine-grained token approval.

## 2. Install

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install --upgrade pip
pip install -r requirements.txt
Copy-Item .env.example .env
```

Edit `.env` with your GitHub token, approved repository list, and Terraform file paths. Never commit `.env`. The UI lets you choose a configured repository, then fetches branches from that repository and lets you select the PR base branch. Environment choices are discovered from tfvars paths on that branch.

```env
GITHUB_TOKEN=YOUR_TOKEN
GITHUB_REPOSITORIES_JSON='[{"owner":"your-org","repo":"terraform-dev","label":"Development"},{"owner":"your-org","repo":"terraform-prod","label":"Production"}]'
TARGET_BASE_BRANCH=main  # fallback/default only
GITHUB_API_URL=https://api.github.com
TARGET_MAIN_FILE=main.tf
TARGET_OUTPUTS_FILE=outputs.tf
TARGET_VARIABLES_FILE=variables.tf
TARGET_ENV_TFVARS_PATTERN=env/{environment}/{environment}.tfvars
```

## 3. Run

From the project root:

```powershell
streamlit run ui/streamlit_app.py
```

The app lists configured repositories in a dropdown, fetches branches for the selected repository, discovers environment tfvars files on the selected branch, and scans that repository/branch/environment. Add multiple assignments; each can be an AD group or managed identity, one scope, and multiple approved roles. Review the complete `main.tf`, `variables.tf`, and environment `.tfvars` diffs, then create one PR for all assignments.

## 4. Discovery behavior

- Reads configured root `main.tf`, `outputs.tf`, `variables.tf`, and environment `.tfvars`.
- Scans module output references and existing IAM module blocks for candidate scopes and principals.
- Shows the source file and confidence description for detected expressions.
- Keeps dynamic expressions as Terraform expressions rather than trying to resolve Azure runtime IDs.
- Uses a catalog for approved IAM module source/version and role keys. That catalog is intentionally separate from discovered resource/principal expressions.
- The app creates a feature branch from the selected base branch, commits modified files, and opens a PR against that selected branch in the selected repository.

## 5. Limitations / review checklist

1. Terraform HCL parsing here uses conservative regular expressions, not a full HCL parser. Complex nested blocks, heredocs, and unusual formatting may need a proper HCL parser before production use.
2. Discovery is heuristic. A resource/module output named `*_id` may be a valid scope candidate but must be reviewed by a Terraform owner. The app does not know Azure RBAC semantics solely from a variable name.
3. The demo `outputs.tf` shows typical output patterns. In a real repository, configure the actual paths and check that outputs are exposed at the root module.
4. The app creates a PR but does not run `terraform fmt`, `terraform validate`, policy checks, or `terraform plan`. Add required CI checks and branch protection.
5. Before production, add tests, audit logging, environment allowlists, ticket-system validation, approvals, concurrency controls, and least-privilege token handling.
6. This MVP edits one root `main.tf`, one root `variables.tf`, and one tfvars file for the selected environment. Each selected role becomes a module instance. It does not edit arbitrary module files or remote module source code. Multi-repository access is restricted to the allow-list in `GITHUB_REPOSITORIES_JSON`; do not accept arbitrary repository names from untrusted users.

## 6. GitHub 401 troubleshooting

- Test the token without sharing it:
  ```powershell
  $token = Read-Host "Enter GitHub token"
  $headers = @{ Authorization = "Bearer $token"; Accept = "application/vnd.github+json"; "X-GitHub-Api-Version" = "2022-11-28" }
  Invoke-RestMethod -Uri "https://api.github.com/user" -Headers $headers
  ```
- If this fails with 401, create a new token and check that it was copied completely.
- If it succeeds but the app fails, remove a stale environment override in the current PowerShell session:
  ```powershell
  Remove-Item Env:GITHUB_TOKEN -ErrorAction SilentlyContinue
  ```
  Restart Streamlit after changing `.env`.
- For fine-grained tokens, confirm the correct resource owner, repository selection, permissions, and organization approval.


## UI security and information exposure

- The UI does not render or allow editing of the GitHub token, GitHub API URL, or other `.env` values. Repository choices come from the configured allow-list; branches are fetched from the selected repository.
- `.env` remains local configuration and must not be committed. Rotate the token immediately if it has ever been exposed or committed.
- The preview shows diffs for `main.tf`, `variables.tf`, and the selected environment `.tfvars` file. Reviewable request values such as AD group Object IDs, role, environment, DPC and EAI codes are shown; assignments with credential-like names (for example passwords, tokens, secrets, private keys, and connection strings) are masked in the UI preview. The pull request contains the actual generated file changes for authorized reviewers.
- GitHub pull requests contain the actual generated changes and are visible to users with repository access; use repository permissions and branch protection to control access.
- Error messages are shown to help troubleshoot API issues; do not add token values or full environment dumps to exception messages or logs.
