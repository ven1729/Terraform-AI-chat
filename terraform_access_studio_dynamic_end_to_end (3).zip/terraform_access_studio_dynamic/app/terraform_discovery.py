import re
from dataclasses import dataclass, asdict

@dataclass
class Choice:
    label: str
    expression: str
    kind: str
    source_file: str
    confidence: str = "Detected"

MODULE_RE = re.compile(r'module\s+"([^"]+)"\s*\{(.*?)\n\}', re.S)
OUTPUT_RE = re.compile(r'output\s+"([^"]+)"\s*\{(.*?)\n\}', re.S)
RESOURCE_RE = re.compile(r'resource\s+"([^"]+)"\s+"([^"]+)"\s*\{', re.S)
ROLE_HINTS = {
    "key vault": "role_definition_keyvault_contributor",
    "keyvault": "role_definition_keyvault_contributor",
    "storage": "role_definition_storage_blob_data_contributor",
    "blob": "role_definition_storage_blob_data_contributor",
    "reader": "role_definition_name_reader",
    "databricks": "role_definition_name_reader",
}
ROLE_CHOICES = [
    ("Key Vault Secrets Officer", "role_definition_keyvault_secret_officer", "key_vault"),
    ("Key Vault Contributor", "role_definition_keyvault_contributor", "key_vault"),
    ("Storage Blob Data Contributor", "role_definition_storage_blob_data_contributor", "storage_account"),
    ("Reader", "role_definition_name_reader", "any"),
]

def blocks(pattern, text):
    return [(m.group(1), m.group(2)) for m in pattern.finditer(text or "")]

def discover(configured_files):
    main = configured_files.get("main.tf", "")
    outputs = configured_files.get("outputs.tf", "")
    vars_text = configured_files.get("variables.tf", "")
    tfvars = configured_files.get("tfvars", "")
    choices = []
    module_names = [name for name, _ in blocks(MODULE_RE, main)]
    # Output declarations are the clearest source of root-exposed IDs.
    for name, body in blocks(OUTPUT_RE, outputs):
        value_match = re.search(r'value\s*=\s*([^\n]+)', body)
        if not value_match:
            continue
        expr = value_match.group(1).strip().rstrip(",")
        low = (name + " " + expr).lower()
        if "principal" in low or "identity" in low or "object_id" in low:
            choices.append(Choice(f"Principal • output.{name}", expr, "principal", "outputs.tf"))
        elif any(k in low for k in ("_id", "resourceid", "resource_id", "scope")):
            choices.append(Choice(f"Scope • output.{name}", expr, "scope", "outputs.tf"))
    # Existing root module references help discover IDs even when outputs.tf doesn't expose them.
    module_exprs = re.findall(r'\b(module\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+(?:\[[^\]]+\])?)', main)
    for expr in sorted(set(module_exprs)):
        low = expr.lower()
        kind = "principal" if any(k in low for k in ("principal", "identity", "object_id")) else (
            "scope" if any(k in low for k in ("_id", "resourceid", "resource_id")) else None)
        if kind:
            label = f"{kind.title()} • {expr}"
            if not any(c.expression == expr and c.kind == kind for c in choices):
                choices.append(Choice(label, expr, kind, "main.tf", "Inferred from existing module references"))
    # Existing IAM blocks can contain the most direct examples of valid scope/principal expressions.
    for name, body in blocks(MODULE_RE, main):
        low = name.lower()
        if "iam" not in low and "role-assignment" not in low:
            continue
        for field, kind in (("scope", "scope"), ("principal_id", "principal")):
            m = re.search(rf'\b{field}\s*=\s*(.+)', body)
            if m:
                expr = m.group(1).strip().split("#")[0].strip()
                if expr and not any(c.expression == expr and c.kind == kind for c in choices):
                    choices.append(Choice(f"{kind.title()} • existing {name}: {expr}", expr, kind, "main.tf", "Existing IAM example"))
    # Generic Azure resource IDs are a fallback discovery path.
    for rtype, rname in RESOURCE_RE.findall(main):
        expr = f"{rtype}.{rname}.id"
        if not any(c.expression == expr and c.kind == "scope" for c in choices):
            choices.append(Choice(f"Scope • {expr}", expr, "scope", "main.tf", "Resource block inferred; verify attribute"))
    # Prefer only non-empty and distinct choices.
    dedup = {}
    for c in choices:
        key = (c.kind, c.expression)
        dedup.setdefault(key, c)
    choices = list(dedup.values())
    principals = [c for c in choices if c.kind == "principal"]
    scopes = [c for c in choices if c.kind == "scope"]
    # If an outputs.tf output name is exposed but its expression is a module output, retain the output expression as well.
    return {
        "modules": module_names,
        "scopes": [asdict(c) for c in scopes],
        "principals": [asdict(c) for c in principals],
        "variables": sorted(set(re.findall(r'variable\s+"([^"]+)"', vars_text))),
        "tfvars_variables": sorted(set(re.findall(r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=', tfvars, re.M))),
        "roles": ROLE_CHOICES,
    }

def suggest_role(resource_label):
    low = resource_label.lower()
    for key, role in ROLE_HINTS.items():
        if key in low:
            return role
    return "role_definition_name_reader"
