import re
import time
from app.terraform_discovery import discover
from app.terraform_editor import ensure_variable, set_tfvar, make_module_block, append_module

GUID_RE = re.compile(r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$")


class AccessWorkflow:
    def __init__(self, gh, config, module_catalog, base_branch=None):
        self.gh, self.config, self.catalog = gh, config, module_catalog
        self.base_branch = base_branch or config.get("default_branch", "main")

    def list_environments(self):
        tree, _ = self.gh.get_tree(self.base_branch)
        paths = [item["path"] for item in tree if item.get("type") == "blob"]
        found = set()
        for path in paths:
            match = re.search(r"(?:^|/)env/([^/]+)/\1\.tfvars$", path, re.I)
            if match:
                found.add(match.group(1))
        for path in paths:
            match = re.search(r"(?:^|/)([A-Za-z0-9_-]+)\.tfvars$", path)
            if match:
                found.add(match.group(1))
        return sorted(found, key=str.lower)

    def scan(self, environment):
        tree, _ = self.gh.get_tree(self.base_branch)
        paths = {item["path"] for item in tree if item.get("type") == "blob"}
        main_path = self.config["main_file"]
        out_path = self.config["outputs_file"]
        var_path = self.config["variables_file"]
        tfvars_path = self.config["tfvars_pattern"].format(environment=environment)

        def find_path(preferred, candidates):
            if preferred in paths:
                return preferred
            for candidate in candidates:
                if candidate in paths:
                    return candidate
            matches = [p for p in paths if p.endswith("/" + preferred) or p == preferred]
            return matches[0] if len(matches) == 1 else preferred

        main_path = find_path(main_path, ["main.tf"])
        out_path = find_path(out_path, ["outputs.tf"])
        var_path = find_path(var_path, ["variables.tf"])
        tfvars_path = find_path(tfvars_path, [f"{environment}.tfvars", f"env/{environment}/{environment}.tfvars"])
        texts, shas = {}, {}
        for key, path in (("main.tf", main_path), ("outputs.tf", out_path), ("variables.tf", var_path), ("tfvars", tfvars_path)):
            try:
                texts[key], shas[path] = self.gh.get_file(path, self.base_branch)
            except Exception as exc:
                if key == "main.tf":
                    raise RuntimeError(f"Could not read required file {path}: {exc}") from exc
                if key == "tfvars" and path not in paths:
                    texts[key] = ""
                elif key == "variables.tf" and path not in paths:
                    texts[key] = ""
                else:
                    texts[key] = ""
        return {"paths": {"main.tf": main_path, "outputs.tf": out_path, "variables.tf": var_path, "tfvars": tfvars_path},
                "texts": texts, "shas": shas, "discovery": discover(texts), "environment": environment,
                "base_branch": self.base_branch}

    @staticmethod
    def _slug(value):
        value = re.sub(r"[^A-Za-z0-9_-]+", "_", str(value)).strip("_-").lower()
        return value[:45] or "assignment"

    def prepare(self, request):
        assignments = request.get("assignments") or []
        if not assignments:
            raise ValueError("Add at least one access assignment.")
        scanned = self.scan(request["environment"])
        scanned["original_texts"] = dict(scanned["texts"])
        d = scanned["discovery"]
        existing_vars = set(d.get("variables", []))
        module_names = []
        used_names = set()
        normalized = []

        for index, assignment in enumerate(assignments, start=1):
            access_type = assignment.get("access_type", "")
            if access_type not in ("AD Group Access", "Managed Identity"):
                raise ValueError(f"Assignment {index}: choose AD Group Access or Managed Identity.")
            scope_expr = assignment.get("scope_expression", "")
            if not any(x.get("expression") == scope_expr for x in d.get("scopes", [])):
                raise ValueError(f"Assignment {index}: selected scope is not present in the current repository scan.")
            roles = assignment.get("roles") or []
            if not roles:
                raise ValueError(f"Assignment {index}: select at least one IAM role.")
            for role in roles:
                if role not in self.catalog.get("roles", {}):
                    raise ValueError(f"Assignment {index}: role {role!r} is not in the approved catalog.")

            principal_expr = ""
            if access_type == "Managed Identity":
                principal_expr = assignment.get("principal_expression", "")
                if not any(x.get("expression") == principal_expr for x in d.get("principals", [])):
                    raise ValueError(f"Assignment {index}: select a managed identity/principal discovered from this branch.")
            else:
                group_id = assignment.get("group_object_id", "").strip()
                approver_id = assignment.get("approver_group_id", "").strip()
                if not GUID_RE.fullmatch(group_id):
                    raise ValueError(f"Assignment {index}: AD group Object ID must be a GUID.")
                if not GUID_RE.fullmatch(approver_id):
                    raise ValueError(f"Assignment {index}: approver group Object ID must be a GUID.")

            suffix = self._slug(f"{assignment.get('label') or 'assignment'}_{index}")
            group_var = f"group_object_id_{suffix}"
            approver_var = f"approver_group_id_{suffix}"
            if access_type == "AD Group Access":
                for name, desc, value in ((group_var, "Microsoft Entra ID group object ID", group_id),
                                          (approver_var, "Approver group object ID", approver_id)):
                    scanned["texts"]["variables.tf"] = ensure_variable(scanned["texts"]["variables.tf"], name, desc)
                    scanned["texts"]["tfvars"] = set_tfvar(scanned["texts"]["tfvars"], name, value)
                    existing_vars.add(name)

            for role in roles:
                role_var = self.catalog["roles"][role]["value"]
                if role_var not in existing_vars:
                    scanned["texts"]["variables.tf"] = ensure_variable(scanned["texts"]["variables.tf"], role_var, f"Approved role key for {role}")
                    existing_vars.add(role_var)
                scanned["texts"]["tfvars"] = set_tfvar(scanned["texts"]["tfvars"], role_var, role_var)
                module_kind = "ad_group" if access_type == "AD Group Access" else "managed_identity"
                module_cfg = self.catalog["modules"][module_kind]
                module_suffix = f"{self._slug(request['ticket'])}_{suffix}_{self._slug(role)}"
                module_name = f"{module_cfg['prefix'].replace('-', '_')}_{module_suffix}"
                if module_name in used_names:
                    module_name += f"_{index}"
                used_names.add(module_name)
                block = make_module_block(module_name, module_cfg["source"], module_cfg["version"], role_var,
                                          scope_expr, principal_expr, access_type, group_var, approver_var,
                                          assignment.get("principal_type", "ServicePrincipal"))
                scanned["texts"]["main.tf"] = append_module(scanned["texts"]["main.tf"], block, module_name)
                module_names.append(module_name)
            normalized.append({"label": assignment.get("label") or f"Assignment {index}",
                               "access_type": access_type, "scope_expression": scope_expr,
                               "roles": list(roles), "principal_expression": principal_expr,
                               "principal_type": assignment.get("principal_type", "ServicePrincipal"),
                               "group_object_id": assignment.get("group_object_id", "").strip() if access_type == "AD Group Access" else ""})

        for name, desc in [("dpc_code", "DPC or application code"), ("eai_code", "EAI identifier"), ("environment", "Environment name")]:
            scanned["texts"]["variables.tf"] = ensure_variable(scanned["texts"]["variables.tf"], name, desc)
        for name, value in [("dpc_code", request.get("dpc_code", "")), ("eai_code", request.get("eai_code", "")), ("environment", request["environment"])]:
            scanned["texts"]["tfvars"] = set_tfvar(scanned["texts"]["tfvars"], name, value)

        scanned["module_names"] = module_names
        scanned["module_name"] = ", ".join(module_names)
        scanned["input_request"] = {**request, "assignments": [dict(item) for item in assignments]}
        scanned["request"] = {**request, "assignments": normalized}
        scanned["tfvars_changed_keys"] = self._changed_tfvar_keys(scanned["original_texts"].get("tfvars", ""), scanned["texts"]["tfvars"])
        return scanned

    @staticmethod
    def _changed_tfvar_keys(before, after):
        def assignments(text):
            return {m.group(1): m.group(2).strip() for m in re.finditer(r'^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*?)\s*$', text or "", re.M)}
        old, new = assignments(before), assignments(after)
        return sorted(name for name in set(old) | set(new) if old.get(name) != new.get(name))

    def publish(self, prepared):
        request = prepared["request"]
        ticket = self._slug(request["ticket"])
        base = prepared.get("base_branch") or self.base_branch
        branch = f"feature/access-{ticket}-{int(time.time())}"
        self.gh.create_branch(branch, base)
        paths, texts, shas = prepared["paths"], prepared["texts"], prepared["shas"]
        changes = []
        for key in ("main.tf", "variables.tf", "tfvars"):
            path = paths[key]
            original = shas.get(path)
            self.gh.put_file(path, texts[key], branch, f"Add Terraform access for {request['ticket']}", sha=original)
            changes.append(path)
        assignment_lines = []
        for item in request["assignments"]:
            principal = item.get("principal_expression") or "AD group Object ID supplied in tfvars"
            assignment_lines.append(f"- **{item['label']}** — {item['access_type']}; roles: {', '.join(item['roles'])}; scope: `{item['scope_expression']}`; principal: `{principal}`")
        body = ("## Terraform access request\n\n"
                f"- **Ticket:** {request['ticket']}\n- **Environment:** {request['environment']}\n"
                f"- **Base branch:** `{base}`\n- **Assignments:** {len(request['assignments'])}\n\n"
                + "\n".join(assignment_lines) + "\n\n"
                "Generated by Terraform Access Studio. Review the diff, run `terraform fmt` and `terraform validate`, "
                "then inspect a Terraform plan before merging. This PR does not apply infrastructure changes.\n")
        pr = self.gh.create_pr(f"[{request['ticket']}] Terraform access assignments", body, branch, base)
        return {"branch": branch, "base_branch": base, "pr_url": pr["html_url"], "files": changes, "module_names": prepared["module_names"]}
