import json
import os
from dotenv import load_dotenv

load_dotenv()


def get_config():
    """Load credentials and an explicit allow-list of selectable repositories."""
    token = os.getenv("GITHUB_TOKEN", "").strip()
    api_url = os.getenv("GITHUB_API_URL", "https://api.github.com").rstrip("/")
    repositories = []
    raw = os.getenv("GITHUB_REPOSITORIES_JSON", "").strip()
    if raw:
        try:
            parsed = json.loads(raw)
            if not isinstance(parsed, list):
                raise ValueError("GITHUB_REPOSITORIES_JSON must be a JSON list")
            for item in parsed:
                if not isinstance(item, dict):
                    continue
                owner = str(item.get("owner", "")).strip()
                repo = str(item.get("repo", "")).strip()
                if owner and repo:
                    repositories.append({"owner": owner, "repo": repo,
                                         "label": str(item.get("label") or f"{owner}/{repo}")})
        except (json.JSONDecodeError, ValueError) as exc:
            raise RuntimeError(f"Invalid GITHUB_REPOSITORIES_JSON: {exc}") from exc
    if not repositories:
        owner = os.getenv("GITHUB_OWNER", "").strip()
        repo = os.getenv("TARGET_REPO", "").strip()
        if owner and repo:
            repositories = [{"owner": owner, "repo": repo, "label": f"{owner}/{repo}"}]
    return {
        "token": token,
        "api_url": api_url,
        "repositories": repositories,
        "default_branch": os.getenv("TARGET_BASE_BRANCH", "main").strip() or "main",
        "main_file": os.getenv("TARGET_MAIN_FILE", "main.tf").strip() or "main.tf",
        "outputs_file": os.getenv("TARGET_OUTPUTS_FILE", "outputs.tf").strip() or "outputs.tf",
        "variables_file": os.getenv("TARGET_VARIABLES_FILE", "variables.tf").strip() or "variables.tf",
        "tfvars_pattern": os.getenv("TARGET_ENV_TFVARS_PATTERN", "env/{environment}/{environment}.tfvars").strip(),
    }
